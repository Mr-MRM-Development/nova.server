const gameBoard = document.getElementById("gameBoard");
const timeLabel = document.getElementById("timeLabel");
const minesLabel = document.getElementById("minesLabel");

const ROWS = 10;
const COLS = 10;
const MINE_COUNT = 10;

let board = [];
let gameOver = false;
let firstClick = true;
let flags = 0;
let revealed = 0;
let timer = 0;
let timerInterval = null;


// ==========================
// NEW GAME
// ==========================

function newGame() {
    clearInterval(timerInterval);

    board = [];
    gameOver = false;
    firstClick = true;
    flags = 0;
    revealed = 0;
    timer = 0;

    timeLabel.textContent = "00:00";
    minesLabel.textContent = MINE_COUNT;

    gameBoard.innerHTML = "";

    // Buat data board
    for (let row = 0; row < ROWS; row++) {
        board[row] = [];

        for (let col = 0; col < COLS; col++) {
            board[row][col] = {
                mine: false,
                revealed: false,
                flagged: false,
                adjacent: 0,
                element: null
            };
        }
    }

    // Render DOM
    for (let row = 0; row < ROWS; row++) {
        const rowElement = document.createElement("div");
        rowElement.className = "board-row";

        for (let col = 0; col < COLS; col++) {
            const field = document.createElement("div");

            field.className = "board-field";

            field.dataset.row = row;
            field.dataset.col = col;

            // Klik kiri
            field.addEventListener("click", () => {
                handleClick(row, col);
            });

            // Klik kanan
            field.addEventListener("contextmenu", (event) => {
                event.preventDefault();
                toggleFlag(row, col);
            });

            board[row][col].element = field;

            rowElement.appendChild(field);
        }

        gameBoard.appendChild(rowElement);
    }
}


// ==========================
// MINE GENERATION
// ==========================

function generateMines(safeRow, safeCol) {
    let placed = 0;

    while (placed < MINE_COUNT) {
        const row = Math.floor(Math.random() * ROWS);
        const col = Math.floor(Math.random() * COLS);

        // Klik pertama aman
        if (row === safeRow && col === safeCol) {
            continue;
        }

        // Jangan pasang mine dua kali
        if (board[row][col].mine) {
            continue;
        }

        board[row][col].mine = true;
        placed++;
    }

    calculateNumbers();
}


// ==========================
// CALCULATE NUMBERS
// ==========================

function calculateNumbers() {
    for (let row = 0; row < ROWS; row++) {
        for (let col = 0; col < COLS; col++) {

            if (board[row][col].mine) {
                continue;
            }

            let count = 0;

            for (const [dr, dc] of getNeighbors(row, col)) {
                if (board[dr][dc].mine) {
                    count++;
                }
            }

            board[row][col].adjacent = count;
        }
    }
}


// ==========================
// GET NEIGHBORS
// ==========================

function getNeighbors(row, col) {
    const neighbors = [];

    for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {

            if (dr === 0 && dc === 0) {
                continue;
            }

            const newRow = row + dr;
            const newCol = col + dc;

            if (
                newRow >= 0 &&
                newRow < ROWS &&
                newCol >= 0 &&
                newCol < COLS
            ) {
                neighbors.push([newRow, newCol]);
            }
        }
    }

    return neighbors;
}


// ==========================
// CLICK
// ==========================

function handleClick(row, col) {
    if (gameOver) {
        return;
    }

    const cell = board[row][col];

    if (cell.revealed || cell.flagged) {
        return;
    }

    // Generate mine setelah klik pertama
    if (firstClick) {
        firstClick = false;

        generateMines(row, col);
        startTimer();
    }

    // Kena ranjau
    if (cell.mine) {
        cell.revealed = true;
        cell.element.classList.add("revealed", "mine");

        endGame(false);
        return;
    }

    revealCell(row, col);

    checkWin();
}


// ==========================
// REVEAL CELL
// ==========================

function revealCell(row, col) {
    const cell = board[row][col];

    if (
        cell.revealed ||
        cell.flagged ||
        cell.mine
    ) {
        return;
    }

    cell.revealed = true;
    revealed++;

    cell.element.classList.add("revealed");

    // Tampilkan angka
    if (cell.adjacent > 0) {
        cell.element.textContent = cell.adjacent;
        cell.element.dataset.number = cell.adjacent;
    }

    // Kalau 0, buka area sekitar
    if (cell.adjacent === 0) {
        for (const [nr, nc] of getNeighbors(row, col)) {
            revealCell(nr, nc);
        }
    }
}


// ==========================
// FLAG
// ==========================

function toggleFlag(row, col) {
    if (gameOver) {
        return;
    }

    const cell = board[row][col];

    if (cell.revealed) {
        return;
    }

    // Pasang flag
    if (!cell.flagged) {

        if (flags >= MINE_COUNT) {
            return;
        }

        cell.flagged = true;
        flags++;

        cell.element.classList.add("flagged");
        cell.element.textContent = "⚑";

    } else {

        // Lepas flag
        cell.flagged = false;
        flags--;

        cell.element.classList.remove("flagged");
        cell.element.textContent = "";
    }

    minesLabel.textContent = MINE_COUNT - flags;
}


// ==========================
// TIMER
// ==========================

function startTimer() {
    clearInterval(timerInterval);

    timerInterval = setInterval(() => {
        if (gameOver) {
            return;
        }

        timer++;

        const minutes = Math.floor(timer / 60);
        const seconds = timer % 60;

        timeLabel.textContent =
            String(minutes).padStart(2, "0") +
            ":" +
            String(seconds).padStart(2, "0");

    }, 1000);
}


// ==========================
// END GAME
// ==========================

function endGame(won) {
    gameOver = true;

    clearInterval(timerInterval);

    // Tampilkan semua mine
    for (let row = 0; row < ROWS; row++) {
        for (let col = 0; col < COLS; col++) {

            const cell = board[row][col];

            if (cell.mine) {
                cell.element.classList.add("mine");

                if (!cell.flagged) {
                    cell.element.textContent = "💣";
                }
            }
        }
    }

    if (won) {
        alert("You win!");
        setTimeout(() => {
            newGame();
        }, 100);
    } else {
        alert("Game Over!");
        setTimeout(() => {
            newGame();
        }, 100);
    }
}


// ==========================
// CHECK WIN
// ==========================

function checkWin() {
    const safeCells = ROWS * COLS - MINE_COUNT;

    if (revealed >= safeCells) {
        endGame(true);
    }
}


// ==========================
// START
// ==========================

newGame();


// Supaya onclick="newGame()" dari HTML bisa memanggilnya
window.newGame = newGame;