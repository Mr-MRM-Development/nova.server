import Library from "../lib/Library.js";
import { STATE } from "../state.js";

import SystemWindow from "../lib/SystemWindow.js";

window.openBrowser = openBrowser;
function openBrowser(url) {
    SystemWindow.openAppWindow(
        __dirname + "/../../windows/browser/index.html"
        , {
        name: "Browser",
        icon: __dirname + "/icons.omx",
        content: url
    });
}