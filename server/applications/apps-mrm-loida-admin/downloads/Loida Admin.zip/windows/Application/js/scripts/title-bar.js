const { ipcRenderer } = require("electron");

import Library from "../lib/Library.js";

window.titlebarControls = titlebarControls;
function titlebarControls(method) {
    ipcRenderer.invoke("titlebar-controls", {
        method: method
    });
}