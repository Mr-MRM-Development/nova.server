import Library from "./lib/Library.js";
import { STATE, SYSTEM } from "./state.js";


async function renderWindow() {
    if (SYSTEM.ASSETS.FontAwesome) {
        Library.getSystemAsset("Font-Awesome-7.x", { 
            css: "css/all.css" 
        });
    }

    if (SYSTEM.ASSETS.Bootstrap) {        
        Library.getSystemAsset("Bootstrap-5.3.8-dist", { 
            css: "css/bootstrap.css", 
            js: "js/bootstrap.js" 
        });
    }
    
    if (SYSTEM.ASSETS.HighlightJS) {        
        Library.getSystemAsset("highlightjs", { 
            css: "vs2015.min.css", 
            js: "highlight.min.js" 
        });
    }

    await Library.importHTML(
        "./layouts/title-bar.html", 
        document.querySelector(".title-bar")
    );
    
    await Library.importHTML(
        "./layouts/app.html", 
        document.querySelector(".window-body")
    );
    await Library.importHTML(
        "./layouts/footer.html", 
        document.querySelector("footer")
    );
    
    const { default: OMX } = await Library.getSystemLibrary("omx/main.js");
    OMX.render();
}

renderWindow();