const STATE = {
    // Your Global Variable:
};

const SYSTEM = {
    ASSETS: {
        FontAwesome: true,
        Bootstrap: true
    }
};

export { STATE, SYSTEM };