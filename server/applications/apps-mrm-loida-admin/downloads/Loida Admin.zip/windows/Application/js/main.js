import "./setup.js";
import "./scripts/main.js";

import { STATE } from "./state.js";