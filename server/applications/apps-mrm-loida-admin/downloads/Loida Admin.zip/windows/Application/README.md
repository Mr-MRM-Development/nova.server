# Sample OMERIZ Frame
## &copy;2026 | Mohammad Rizqy Mubarok | 2026 OMERIZ Development Team