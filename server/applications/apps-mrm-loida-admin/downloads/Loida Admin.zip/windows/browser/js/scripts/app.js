import Library from "../lib/Library.js";
import { STATE } from "../state.js";

const { ipcRenderer } = require("electron");

let appPath = "";

ipcRenderer.on("content", async (event, content) => {
    const urlInput = await Library.waitForElement("#urlInput");
    urlInput.value = content;
    appPath = content;
    addBrowserView();
});

window.openURL = async () => {
    const urlInput = await Library.waitForElement("#urlInput");
    appPath = urlInput.value;
    addBrowserView();
}

async function addBrowserView(){
    try {
        const el = await Library.waitForElement("#app");
        
        if(!el) return;

        const rect = el.getBoundingClientRect();
    
        ipcRenderer.invoke("add-browser-view", {
            x: Math.floor(rect.x),
            y: Math.floor(rect.y),
            width: Math.floor(rect.width),
            height: Math.floor(rect.height),
            appPath: appPath
        });
    } catch (error) {
        alert(error);
    }
}

async function updateViewBounds(){
    
    const el = await Library.waitForElement("#app");
    if(!el) return;
    const rect = el.getBoundingClientRect();

    ipcRenderer.invoke("set-browser-view", {
        x: Math.floor(rect.x),
        y: Math.floor(rect.y),
        width: Math.floor(rect.width),
        height: Math.floor(rect.height),
    });
}

window.addEventListener("resize", updateViewBounds);

new ResizeObserver(updateViewBounds).observe(
    await Library.waitForElement("#app")
);

// updateViewBounds();

// await Library.waitForElement("#urlInput").addEventListener("keydown", (e) => {
//     if (e.key === "Enter") {
//         openURL();
//     }
// })