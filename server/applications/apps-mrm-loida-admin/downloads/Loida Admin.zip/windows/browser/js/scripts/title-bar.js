const { ipcRenderer } = require("electron");

import Library from "../lib/Library.js";

let maximized = false;

window.titlebarControls = titlebarControls;
function titlebarControls(method) {
    if (method === "maxAndRes") {
        if (maximized) {
            ipcRenderer.invoke("titlebar-controls", {
                method: "resize"
            });

            maximized = false;
        } else {
            ipcRenderer.invoke("titlebar-controls", {
                method: "maximize"
            });

            maximized = true;
        }
    } else {
        ipcRenderer.invoke("titlebar-controls", {
            method: method
        });
    }
}