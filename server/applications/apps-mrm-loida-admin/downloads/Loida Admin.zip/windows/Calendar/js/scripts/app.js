import Library from "../lib/Library.js";
import { STATE } from "../state.js";

// calendar.js

export class Calendar {
  constructor() {
    this.date = new Date();
    this.elements = {};
  }

  async init() {
    // Mengambil elemen secara aman menggunakan helper framework kamu
    this.elements = {
      month: await Library.waitForElement('#calendar-month'),
      year: await Library.waitForElement('#calendar-year'),
      daysContainer: await Library.waitForElement('#calendar-days'),
      prevBtn: await Library.waitForElement('#prev-month-btn'),
      nextBtn: await Library.waitForElement('#next-month-btn'),
      prevBtnTitle: await Library.waitForElement('#prev-month-btn-title'),
      nextBtnTitle: await Library.waitForElement('#next-month-btn-title'),
      todayBtn: await Library.waitForElement('#today-btn')
    };

    this.bindEvents();
    this.render();
  }

  bindEvents() {
    this.elements.prevBtn.addEventListener('click', () => this.changeMonth(-1));
    this.elements.nextBtn.addEventListener('click', () => this.changeMonth(1));
    this.elements.prevBtnTitle.addEventListener('click', () => this.changeMonth(-1));
    this.elements.nextBtnTitle.addEventListener('click', () => this.changeMonth(1));
    this.elements.todayBtn.addEventListener('click', () => this.goToToday());
  }

  changeMonth(offset) {
    this.date.setMonth(this.date.getMonth() + offset);
    this.render();
  }

  goToToday() {
    this.date = new Date();
    this.render();
  }

  render() {
    const year = this.date.getFullYear();
    const month = this.date.getMonth();

    // Set Teks Header
    const monthNames = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    this.elements.month.textContent = monthNames[month];
    this.elements.year.textContent = year;

    // Kalkulasi Hari
    const firstDayIndex = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();
    const prevLastDate = new Date(year, month, 0).getDate();
    const today = new Date();

    let daysHTML = '';

    // Tanggal Bulan Sebelumnya
    for (let x = firstDayIndex; x > 0; x--) {
      daysHTML += `<div class="day prev-month">${prevLastDate - x + 1}</div>`;
    }

    // Tanggal Bulan Ini
    for (let i = 1; i <= lastDate; i++) {
      const isToday = 
        i === today.getDate() && 
        month === today.getMonth() && 
        year === today.getFullYear();

      daysHTML += `<div class="day ${isToday ? 'today' : ''}" data-date="${year}-${month + 1}-${i}">${i}</div>`;
    }

    // Tanggal Bulan Berikutnya (Pelengkap Grid)
    const totalSlots = firstDayIndex + lastDate;
    const nextDays = (7 - (totalSlots % 7)) % 7;
    for (let j = 1; j <= nextDays; j++) {
      daysHTML += `<div class="day next-month">${j}</div>`;
    }

    this.elements.daysContainer.innerHTML = daysHTML;
  }
}

// Inisialisasi Module
const calendar = new Calendar();
calendar.init();