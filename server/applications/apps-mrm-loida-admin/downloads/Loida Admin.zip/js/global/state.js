const SYSTEM = {
    ASSETS: {
        FontAwesome: true,
        Bootstrap: true
    }
};

const STATE = {
    // ==================== DATABASE ====================
    database: {
        list: [],           // Semua database
        filteredList: [],   // Hasil filter (opsional untuk cache)
        pagination: {
            currentPage: 1,
            pageSize: 5
        },
        name: ""            // Database yang sedang aktif
    },

    // ==================== TABLE ====================
    table: {
        list: [],           // Semua table di database aktif
        filteredList: [],   // Hasil filter
        pagination: {
            currentPage: 1,
            pageSize: 5
        },
        name: ""            // Table yang sedang aktif (untuk tab record)
    },

    // ==================== RECORD ====================
    record: {
        list: [],           // Semua record di table aktif
        filteredList: [],   // Hasil filter
        columns: [],        // Schema kolom table aktif (cache)
        pagination: {
            currentPage: 1,
            pageSize: 5
        }
    },

    // ==================== DIALOG ====================
    dialog: {
        table: {
            create: {
                name: "",
                fields: []
            }
        },
        record: {
            create: {
                isOpen: false,
                tableName: "",
                databaseName: ""
            }
        }
    }
};

export { SYSTEM, STATE };