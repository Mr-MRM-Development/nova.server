import Library from "../lib/Library.js";

const ELEMENT = {
    mainTab: {
        tabs: {
            database: {
                tbody: await Library.waitForElement("#database-table tbody"),
                create: {
                    input: await Library.waitForElement("#create-database-input")
                },
                filterInput: await Library.waitForElement("#db-filter-input"),
                limitSelect: await Library.waitForElement("#db-limit-select"),
                paginationContainer: await Library.waitForElement("#db-pagination")
            },
            table: {
                tbody: await Library.waitForElement("#table-table tbody"),
                selectDB: await Library.waitForElement("#table-database-select"),
                filterInput: await Library.waitForElement("#tb-filter-input"),
                limitSelect: await Library.waitForElement("#tb-limit-select"),
                paginationContainer: await Library.waitForElement("#tb-pagination")
            },
            record: {
                select: {
                    database: await Library.waitForElement("#record-select-database"),
                    table:    await Library.waitForElement("#record-select-table")
                },
                tbody: await Library.waitForElement("#record-table tbody"),
                filterInput: await Library.waitForElement("#rc-filter-input"),
                limitSelect: await Library.waitForElement("#rc-limit-select"),
                paginationContainer: await Library.waitForElement("#rc-pagination"),
                btnCreate: await Library.waitForElement("#btn-create-record"),
                thead: await Library.waitForElement("#record-table thead tr")
            }
        }
    },
    dialog: {
        table: {
            create: {
                nameInput: await Library.waitForElement("#create-table-name-input"),
                tbody: await Library.waitForElement("#create-table-fields-list-tbody"),
                fields: [],
            }
        },
        record: {
            create: {
                get overlay()       { return document.querySelector("#create-record-dialog"); },
                get formContainer() { return document.querySelector("#create-record-form-container"); },
                get confirmBtn()    { return document.querySelector("#create-record-dialog #modal-confirm-btn"); },
                get nameLabel()     { return document.querySelector("#create-record-dialog #create-record-table-name"); }
            }
        }
    }
};

export { ELEMENT };