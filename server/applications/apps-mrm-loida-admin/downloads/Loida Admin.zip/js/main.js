import "./setup.js"
import "./app/main.js"
import "./scripts/main.js"