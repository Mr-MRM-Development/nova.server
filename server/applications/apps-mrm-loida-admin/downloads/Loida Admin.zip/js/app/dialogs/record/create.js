import Library from "../../../lib/Library.js";

const { default: LOIDA } = await Library.getSystemLibrary("loida/main.js");
import { ELEMENT } from "../../../global/element.js";
import { STATE } from "../../../global/state.js";

const CreateRecord = {
    fields: [],
    isSubmitting: false,

    // ==========================================================
    // OPEN
    // ==========================================================
    async open() {
        const dbName = STATE.database?.name;
        const tbName = STATE.table?.name;

        if (!dbName || !tbName) {
            alert("Please select Database and Table first.");
            return;
        }

        // ✅ FIX: query ulang overlay SETELAH ensureDialogHTML
        let overlay = document.querySelector("#create-record-dialog");
        if (!overlay) {
            await this.ensureDialogHTML();
            overlay = document.querySelector("#create-record-dialog");
        }

        if (!overlay) {
            alert("Dialog HTML failed to load.");
            return;
        }

        try {
            const database = new LOIDA(dbName);
            const tableSchema = await database.table.open(tbName);

            if (!tableSchema?.cols || Object.keys(tableSchema.cols).length === 0) {
                alert("This table has no columns defined.");
                return;
            }

            // Set label target
            const dbLabel = document.querySelector("#create-record-database-name");
            const tbLabel = document.querySelector("#create-record-table-name");
            if (dbLabel) dbLabel.value = dbName;
            if (tbLabel) tbLabel.value = tbName;

            // Render form
            this.renderForm(tableSchema);

            // ✅ FIX: bind submit SETELAH dialog dipastikan ada
            this.bindSubmit();

            // Tampilkan
            showDialogModal("#create-record-dialog");
        } catch (error) {
            console.error("[CreateRecord.open]", error);
            alert(error.message);
        }
    },

    // ==========================================================
    // AUTO-LOAD HTML DIALOG
    // ==========================================================
    async ensureDialogHTML() {
        try {
            const response = await fetch(new URL("./create.html", import.meta.url));
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const html = await response.text();

            const wrapper = document.createElement("div");
            wrapper.innerHTML = html.trim();
            document.body.appendChild(wrapper.firstElementChild);

            // ✅ FIX: tunggu 1 frame biar DOM ready
            await new Promise(r => requestAnimationFrame(r));
        } catch (error) {
            console.error("[CreateRecord.ensureDialogHTML]", error);
            throw new Error("Dialog HTML not found. Please include create.html manually.");
        }
    },

    // ==========================================================
    // BIND SUBMIT
    // ==========================================================
    bindSubmit() {
        const btn = document.querySelector("#create-record-dialog #modal-confirm-btn");
        if (!btn) {
            console.warn("[CreateRecord.bindSubmit] confirmBtn not found!");
            return;
        }

        // Hindari double bind
        btn.onclick = (e) => {
            e.preventDefault();
            this.create();
        };
    },

    // ==========================================================
    // RENDER FORM
    // ==========================================================
    renderForm(tableSchema) {
        const container = document.querySelector("#create-record-form-container");
        if (!container) {
            console.error("[CreateRecord.renderForm] container not found!");
            return;
        }

        const cols = tableSchema.cols || {};
        this.fields = Object.entries(cols).map(([name, config]) => ({ name, config }));

        let html = "";

        for (const { name, config } of this.fields) {
            const type       = config.type || "text";
            const isAuto     = config.autoIncrement === true;
            const required   = config.null === false && !isAuto;
            const hasDefault = Object.prototype.hasOwnProperty.call(config, "default");

            // ---- Auto Increment: tampilkan disabled ----
            if (isAuto) {
                html += `
                    <div class="mb-3">
                        <label class="form-label text-light">
                            ${name}
                            <span class="badge bg-secondary ms-1">Auto</span>
                        </label>
                        <input type="text" class="form-control" value="[Auto Increment]" disabled>
                    </div>
                `;
                continue;
            }

            // ---- Label ----
            html += `
                <div class="mb-3">
                    <label class="form-label text-light">
                        ${name}
                        ${required ? '<span class="text-danger">*</span>' : ''}
                        ${hasDefault ? `<span class="badge bg-secondary ms-1">Default: ${config.default}</span>` : ''}
                        <span class="badge bg-dark ms-1">${type}</span>
                    </label>
            `;

            // ---- Input ----
            switch (type) {
                case "number":
                case "integer":
                case "float":
                case "double":
                    html += `
                        <input type="number" class="form-control record-input"
                            data-column="${name}" data-type="${type}"
                            data-required="${required}"
                            step="${type === "integer" ? "1" : "any"}"
                            ${required ? "required" : ""}
                            placeholder="Enter ${name}...">
                    `;
                    break;

                case "boolean":
                    html += `
                        <select class="form-select record-input"
                            data-column="${name}" data-type="${type}"
                            data-required="${required}"
                            ${required ? "required" : ""}>
                            <option value="">-- Select --</option>
                            <option value="true">true</option>
                            <option value="false">false</option>
                        </select>
                    `;
                    break;

                case "date":
                    html += `
                        <input type="date" class="form-control record-input"
                            data-column="${name}" data-type="${type}"
                            data-required="${required}"
                            ${required ? "required" : ""}>
                    `;
                    break;

                case "datetime":
                case "timestamp":
                    html += `
                        <input type="datetime-local" class="form-control record-input"
                            data-column="${name}" data-type="${type}"
                            data-required="${required}"
                            ${required ? "required" : ""}>
                    `;
                    break;

                case "json":
                case "object":
                case "array":
                    html += `
                        <textarea class="form-control record-input font-monospace"
                            data-column="${name}" data-type="${type}"
                            data-required="${required}"
                            rows="3"
                            ${required ? "required" : ""}
                            placeholder='${type === "array" ? '["item1", "item2"]' : '{"key": "value"}'}'></textarea>
                    `;
                    break;

                default:
                    html += `
                        <input type="text" class="form-control record-input"
                            data-column="${name}" data-type="${type}"
                            data-required="${required}"
                            ${required ? "required" : ""}
                            placeholder="Enter ${name}...">
                    `;
                    break;
            }

            html += `</div>`;
        }

        container.innerHTML = html;

        // ✅ FIX: enable semua input (kadang ada bug disabled dari modal)
        container.querySelectorAll(".record-input").forEach(input => {
            input.disabled = false;
        });
    },

    // ==========================================================
    // COLLECT VALUES
    // ==========================================================
    collectValues() {
        const container = document.querySelector("#create-record-form-container");
        if (!container) return {};

        const inputs = container.querySelectorAll(".record-input");
        const record = {};

        inputs.forEach(input => {
            const column   = input.dataset.column;
            const type     = input.dataset.type;
            const required = input.dataset.required === "true";
            let value      = input.value.trim();

            if (value === "") {
                if (required) {
                    throw new Error(`Column "${column}" is required.`);
                }
                return;
            }

            switch (type) {
                case "number":
                case "integer":
                case "float":
                case "double": {
                    const num = Number(value);
                    if (isNaN(num)) throw new Error(`Invalid number for column "${column}"`);
                    value = num;
                    break;
                }

                case "boolean":
                    value = value === "true";
                    break;

                case "json":
                case "object":
                case "array":
                    try {
                        value = JSON.parse(value);
                    } catch (e) {
                        throw new Error(`Invalid JSON for column "${column}": ${e.message}`);
                    }
                    break;

                case "datetime":
                case "timestamp": {
                    const d = new Date(value);
                    if (isNaN(d.getTime())) throw new Error(`Invalid datetime for column "${column}"`);
                    value = d.getTime();
                    break;
                }

                case "date":
                    value = new Date(value).toISOString().split("T")[0];
                    break;
            }

            record[column] = value;
        });

        return record;
    },

    // ==========================================================
    // SUBMIT
    // ==========================================================
    async create() {
        if (this.isSubmitting) return;
        this.isSubmitting = true;

        const btn = document.querySelector("#create-record-dialog #modal-confirm-btn");
        const originalText = btn?.innerHTML;

        try {
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Saving...`;
            }

            const dbName = STATE.database.name;
            const tbName = STATE.table.name;

            const record = this.collectValues();

            if (Object.keys(record).length === 0) {
                throw new Error("Please fill at least one field.");
            }

            const database = new LOIDA(dbName);
            await database.record.insert(tbName, record);

            hideDialogModal("#create-record-dialog");
            this.reset();

            if (typeof window.renderRecords === "function") {
                window.renderRecords();
            }

            if (window.Toast?.success) {
                window.Toast.success("Record inserted successfully!");
            } else {
                console.log("✅ Record inserted successfully!");
            }
        } catch (error) {
            console.error("[CreateRecord.create]", error);
            alert(error.message);
        } finally {
            this.isSubmitting = false;
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalText || "Create";
            }
        }
    },

    // ==========================================================
    // RESET
    // ==========================================================
    reset() {
        const container = document.querySelector("#create-record-form-container");
        if (container) container.innerHTML = "";

        const dbLabel = document.querySelector("#create-record-database-name");
        const tbLabel = document.querySelector("#create-record-table-name");
        if (dbLabel) dbLabel.value = "";
        if (tbLabel) tbLabel.value = "";

        this.fields = [];
    }
};

window.CreateRecord = CreateRecord;
window.openCreateRecordDialog = () => CreateRecord.open();