import Library     from "../../../lib/Library.js";

import { ELEMENT } from "../../../global/element.js";
import { STATE   } from "../../../global/state.js";

const { default: LOIDA } = await Library.getSystemLibrary("loida/main.js");

class CreateTable {
    static addField(fieldName = "", fieldType = "string", isPK = false, isNullable = true) {
        const tbody = ELEMENT.dialog.table.create.tbody;
        if (!tbody) {
            console.warn("Element tbody untuk dialog create table belum ditemukan.");
            return;
        }

        // 1. Buat elemen <tr> untuk baris baru
        const tr = document.createElement("tr");
        tr.className = "field-row";

        // 2. Isi HTML di dalam baris
        tr.innerHTML = `
            <td>
                <input type="text" class="form-control form-control-sm field-name-input" placeholder="column_name" value="${fieldName}">
            </td>
            <td>
                <select class="form-select form-select-sm field-type-select">
                    <option value="number" ${fieldType === 'number' ? 'selected' : ''}>NUMBER</option>
                    <option value="string" ${fieldType === 'string' ? 'selected' : ''}>STRING</option>
                    <option value="boolean" ${fieldType === 'boolean' ? 'selected' : ''}>BOOLEAN</option>
                    <option value="array" ${fieldType === 'array' ? 'selected' : ''}>ARRAY</option>
                    <option value="option" ${fieldType === 'option' ? 'selected' : ''}>OPTION</option>
                    <option value="datetime" ${fieldType === 'datetime' ? 'selected' : ''}>DATETIME</option>
                    <option value="timestamp" ${fieldType === 'timestamp' ? 'selected' : ''}>TIMESTAMP</option>
                </select>
            </td>
            <td class="text-center">
                <input class="form-check-input field-pk-check" type="checkbox" ${isPK ? 'checked' : ''}>
            </td>
            <td class="text-center">
                <input class="form-check-input field-nullable-check" type="checkbox" ${isNullable ? 'checked' : ''}>
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-danger remove-field-btn" title="Remove">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;

        // 3. Masukkan baris baru ke dalam <tbody>
        tbody.appendChild(tr);

        // 4. Daftarkan elemen baru ke array `ELEMENT.dialog.table.create.fields`
        const fieldObject = {
            row: tr,
            nameInput: tr.querySelector(".field-name-input"),
            typeSelect: tr.querySelector(".field-type-select"),
            pkCheck: tr.querySelector(".field-pk-check"),
            nullableCheck: tr.querySelector(".field-nullable-check"),
            btnRemove: tr.querySelector(".remove-field-btn")
        };

        ELEMENT.dialog.table.create.fields.push(fieldObject);

        // Pasang event listener langsung pada tombol remove yang baru dibuat
        fieldObject.btnRemove.addEventListener("click", () => {
            CreateTable.removeField(fieldObject);
        });
    }

    // Metode untuk Menghapus Field
    static removeField(fieldObject) {
        // Hapus elemen <tr> dari DOM
        if (fieldObject.row && fieldObject.row.parentNode) {
            fieldObject.row.remove();
        }

        // Hapus objek dari array ELEMENT.dialog.table.create.fields
        const fields = ELEMENT.dialog.table.create.fields;
        const index = fields.indexOf(fieldObject);
        if (index !== -1) {
            fields.splice(index, 1);
        }
    }

    // Metode Tambahan untuk Memperbarui STATE
    static setValue() {
        // Update nama tabel ke STATE dari input ELEMENT
        const tableNameInput = ELEMENT.dialog.table.create.nameInput;
        STATE.dialog.table.create.name = tableNameInput ? tableNameInput.value.trim() : "";

        // Ambil data nilai dari setiap elemen UI di ELEMENT.dialog.table.create.fields
        const domFields = ELEMENT.dialog.table.create.fields || [];

        STATE.dialog.table.create.fields = domFields.map((field) => {
            return {
                name: field.nameInput ? field.nameInput.value.trim() : "",
                type: field.typeSelect ? field.typeSelect.value : "string",
                isPK: field.pkCheck ? field.pkCheck.checked : false,
                isNullable: field.nullableCheck ? field.nullableCheck.checked : true
            };
        });

        return STATE.dialog.table.create;
    }

    static async create() {
        this.setValue();

        const tableName = STATE.dialog.table.create.name;
        const fields = STATE.dialog.table.create.fields;

        const columns = {};
        fields.forEach((field) => {
            if (field.name) {
                columns[field.name] = {
                    type: field.type,
                    primaryKey: field.isPK,
                    nullable: field.isNullable
                };
            }
        });

        const database = new LOIDA(STATE.database.name);
        
        await database.table.create(tableName, columns);

        await window.renderTableList();
        await window.hideDialogModal("#create-table-name-input");
    }
}

window.CreateTable = CreateTable;

export default CreateTable;