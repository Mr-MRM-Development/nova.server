import Library from "../lib/Library.js";
import FE from "../lib/FE.js";
import DialogSystem from "../lib/DialogSystem.js";
import SystemWindow from "../lib/SystemWindow.js";

import { ELEMENT } from "../global/element.js";
import { STATE   } from "../global/state.js";

const { default: LOIDA } = await Library.getSystemLibrary("loida/main.js");

import "./dialogs/table/create.js";
import "./dialogs/record/create.js";


// ============================================================
// HELPERS
// ============================================================

function safe(value, fallback = "-") {
    return value === null || value === undefined || value === "" ? fallback : String(value);
}

function escapeHTML(str) {
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function paginate(list, page, pageSize) {
    const totalPages = Math.max(1, Math.ceil(list.length / pageSize));
    const currentPage = Math.min(Math.max(1, page), totalPages);
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;
    return {
        currentPage,
        totalPages,
        items: list.slice(start, end),
        startIndex: start
    };
}


// ============================================================
// TAB: DATABASE
// ============================================================

window.renderDatabaseList = renderDatabaseList;

async function renderDatabaseList(filter = "") {
    const tbody          = ELEMENT.mainTab.tabs.database.tbody;
    const tableSelectDB  = ELEMENT.mainTab.tabs.table.selectDB;
    const recordSelectDB = ELEMENT.mainTab.tabs.record.select.database;

    tbody.innerHTML = "";
    if (tableSelectDB)  tableSelectDB.innerHTML  = "";
    if (recordSelectDB) recordSelectDB.innerHTML = "";

    // ---- Fetch ----
    const databases = await LOIDA.database.list();
    STATE.database.list = databases || [];

    // ---- Kosong ----
    if (STATE.database.list.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="3" class="text-center h3 p-5">No Database Exist</td></tr>
        `;
        renderPaginationUI(0, 1, 1);
        renderTableList(""); // reset table list
        return;
    }

    // ---- Isi dropdown DB (table tab & record tab) ----
    const optionsHTML = STATE.database.list
        .map(db => `<option value="${escapeHTML(db)}">${escapeHTML(db)}</option>`)
        .join("");

    if (tableSelectDB) {
        tableSelectDB.innerHTML = optionsHTML;
        STATE.database.name = tableSelectDB.value;
    }

    if (recordSelectDB) {
        recordSelectDB.innerHTML = optionsHTML;
        STATE.database.name = recordSelectDB.value;
    }

    // ---- Filter ----
    const filteredList = STATE.database.list.filter(db =>
        db.toLowerCase().includes(filter.toLowerCase())
    );

    if (filteredList.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="3" class="text-center h3 p-5">No Database Match</td></tr>
        `;
        renderPaginationUI(0, 1, 1);
        return;
    }

    // ---- Pagination ----
    const pageSize = STATE.database.pagination.pageSize || 5;
    const { currentPage, totalPages, items, startIndex } = paginate(
        filteredList,
        STATE.database.pagination.currentPage,
        pageSize
    );
    STATE.database.pagination.currentPage = currentPage;

    // ---- Render ----
    tbody.innerHTML = items.map((dbName, idx) => {
        const displayIndex = startIndex + idx + 1;
        return `
            <tr>
                <td>${displayIndex}</td>
                <td class="w-100">${escapeHTML(dbName)}</td>
                <td class="d-flex gap-2" style="width: auto;">
                    <button class="btn btn-primary" onclick="deleteDatabase('${escapeHTML(dbName)}')" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="btn btn-primary"
                        onclick="syncAndRenderTable('${escapeHTML(dbName)}'); changeTab('#tab-page-table','#tab-main','#btn-tab-table');"
                        title="View Tables">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join("");

    renderPaginationUI(filteredList.length, currentPage, totalPages);

    // ---- Sync table list ----
    if (tableSelectDB) {
        await renderTableList(tableSelectDB.value);
    }
}

window.syncAndRenderTable = function(dbName) {
    const tableSelectDB = ELEMENT.mainTab.tabs.table.selectDB;

    if (tableSelectDB) {
        tableSelectDB.value = dbName;
        STATE.database.name = dbName;
    }
    renderTableList(dbName);
};


// ============================================================
// PAGINATION UI — DATABASE
// ============================================================

function renderPaginationUI(totalItems, currentPage, totalPages) {
    const container = ELEMENT.mainTab.tabs.database.paginationContainer;
    if (!container) return;

    if (totalItems === 0) {
        container.innerHTML = `<span class="text-secondary fs-7">0 database</span>`;
        return;
    }

    const pageSize = STATE.database.pagination.pageSize;
    const startItem = (currentPage - 1) * pageSize + 1;
    const endItem   = Math.min(currentPage * pageSize, totalItems);

    container.innerHTML = `
        <span class="text-secondary fs-7">
            Menampilkan ${startItem} - ${endItem} dari ${totalItems} database
        </span>
        <div class="btn-group">
            <button class="btn btn-sm btn-secondary"
                ${currentPage === 1 ? "disabled" : ""}
                onclick="changeDBPage(${currentPage - 1})">
                <i class="fas fa-chevron-left"></i> Prev
            </button>
            <span class="btn btn-sm btn-secondary disabled text-light">
                ${currentPage} / ${totalPages}
            </span>
            <button class="btn btn-sm btn-secondary"
                ${currentPage >= totalPages ? "disabled" : ""}
                onclick="changeDBPage(${currentPage + 1})">
                Next <i class="fas fa-chevron-right"></i>
            </button>
        </div>
    `;
}

window.changeDBPage = function(targetPage) {
    STATE.database.pagination.currentPage = targetPage;
    const filterValue = ELEMENT.mainTab.tabs.database.filterInput?.value || "";
    renderDatabaseList(filterValue);
};


// ============================================================
// TAB: TABLE
// ============================================================

window.renderTableList = renderTableList;

async function renderTableList(dbName, filter = "") {
    const tbody = ELEMENT.mainTab.tabs.table.tbody;
    const recordSelectTB = ELEMENT.mainTab.tabs.record.select.table;

    tbody.innerHTML = "";
    if (recordSelectTB) recordSelectTB.innerHTML = "";

    // Fallback DB name
    STATE.database.name = dbName ?? STATE.database.name;
    dbName = STATE.database.name;

    if (!dbName) {
        tbody.innerHTML = `
            <tr><td colspan="3" class="text-center h3 p-5">No Database Selected</td></tr>
        `;
        renderTablePaginationUI(0, 1, 1);
        return;
    }

    // ---- Fetch ----
    const database = new LOIDA(dbName);
    const tables = await database.table.list();
    STATE.table.list = tables || [];

    if (STATE.table.list.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="3" class="text-center h3 p-5">No Table Exist</td></tr>
        `;
        renderTablePaginationUI(0, 1, 1);
        return;
    }

    // ---- Filter ----
    const filteredList = STATE.table.list.filter(t =>
        t.toLowerCase().includes(filter.toLowerCase())
    );

    if (filteredList.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="3" class="text-center h3 p-5">No Table Match</td></tr>
        `;
        renderTablePaginationUI(0, 1, 1);
        return;
    }

    // ---- Isi dropdown table (record tab) ----
    if (recordSelectTB) {
        recordSelectTB.innerHTML = STATE.table.list
            .map(t => {
                const clean = t.split(".")[0];
                return `<option value="${escapeHTML(clean)}">${escapeHTML(clean)}</option>`;
            })
            .join("");

        // Set STATE.table.name dari dropdown
        if (recordSelectTB.value) {
            STATE.table.name = recordSelectTB.value;
        }
    }

    // ---- Pagination ----
    const pageSize = STATE.table.pagination.pageSize || 5;
    const { currentPage, totalPages, items, startIndex } = paginate(
        filteredList,
        STATE.table.pagination.currentPage,
        pageSize
    );
    STATE.table.pagination.currentPage = currentPage;

    // ---- Render ----
    tbody.innerHTML = items.map((tableName, idx) => {
        const displayIndex = startIndex + idx + 1;
        const clean = tableName.split(".")[0];
        return `
            <tr>
                <td>${displayIndex}</td>
                <td>${escapeHTML(tableName)}</td>
                <td class="d-flex gap-2">
                    <button class="btn btn-primary" onclick="deleteTable('${escapeHTML(clean)}')" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="btn btn-primary" title="View Records"
                        onclick="
                            STATE.table.name = '${escapeHTML(clean)}';
                            renderRecords('', STATE.database.name, '${escapeHTML(clean)}');
                            changeTab('#tab-page-record', '#tab-main', '#btn-tab-record');
                        ">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join("");

    renderTablePaginationUI(filteredList.length, currentPage, totalPages);
}


// ============================================================
// PAGINATION UI — TABLE
// ============================================================

function renderTablePaginationUI(totalItems, currentPage, totalPages) {
    const container = ELEMENT.mainTab.tabs.table.paginationContainer;
    if (!container) return;

    if (totalItems === 0) {
        container.innerHTML = `<span class="text-secondary fs-7">0 table</span>`;
        return;
    }

    const pageSize = STATE.table.pagination.pageSize;
    const startItem = (currentPage - 1) * pageSize + 1;
    const endItem   = Math.min(currentPage * pageSize, totalItems);

    container.innerHTML = `
        <span class="text-secondary fs-7">
            Menampilkan ${startItem} - ${endItem} dari ${totalItems} table
        </span>
        <div class="btn-group">
            <button class="btn btn-sm btn-secondary"
                ${currentPage === 1 ? "disabled" : ""}
                onclick="changeTablePage(${currentPage - 1})">
                <i class="fas fa-chevron-left"></i> Prev
            </button>
            <span class="btn btn-sm btn-secondary disabled text-light">
                ${currentPage} / ${totalPages}
            </span>
            <button class="btn btn-sm btn-secondary"
                ${currentPage >= totalPages ? "disabled" : ""}
                onclick="changeTablePage(${currentPage + 1})">
                Next <i class="fas fa-chevron-right"></i>
            </button>
        </div>
    `;
}

window.changeTablePage = function(targetPage) {
    STATE.table.pagination.currentPage = targetPage;
    const filterValue = ELEMENT.mainTab.tabs.table.filterInput?.value || "";
    renderTableList(STATE.database.name, filterValue);
};


// ============================================================
// TAB: RECORD
// ============================================================

window.renderRecords = renderRecords;

async function renderRecords(filter = "", dbName = undefined, tbName = undefined) {
    const tbody    = ELEMENT.mainTab.tabs.record.tbody;
    const theadRow = ELEMENT.mainTab.tabs.record.thead;

    if (!tbody) return;

    tbody.innerHTML = "";
    if (theadRow) theadRow.innerHTML = "";

    // Fallback DB / Table name
    dbName = dbName ?? STATE.database.name;
    tbName = tbName ?? STATE.table.name;

    // Update STATE biar konsisten
    if (dbName) STATE.database.name = dbName;
    if (tbName) STATE.table.name = tbName;

    if (!dbName || !tbName) {
        tbody.innerHTML = `
            <tr><td colspan="3" class="text-center h3 p-5">Please Select Database and Table</td></tr>
        `;
        renderRecordPaginationUI(0, 1, 1);
        return;
    }

    try {
        const database = new LOIDA(dbName);

        // ---- Fetch schema ----
        const tableSchema = await database.table.open(tbName);
        const columns = Object.keys(tableSchema.cols || {});

        // ---- Fetch records ----
        const records = await database.record.select(tbName, ["*"]);
        STATE.record.list = records || [];

        // ---- Render header ----
        if (columns.length > 0 && theadRow) {
            let theadHTML = `<th class="px-3 text-center bg-secondary" style="width:auto;">#</th>`;
            columns.forEach(col => {
                theadHTML += `<th class="px-3 text-center bg-secondary" style="width:auto;">${escapeHTML(col)}</th>`;
            });
            theadHTML += `<th class="px-3 text-center bg-secondary" style="width:auto;">Action</th>`;
            theadRow.innerHTML = theadHTML;
        }

        const colSpan = columns.length + 2;

        // ---- Kosong ----
        if (STATE.record.list.length === 0) {
            tbody.innerHTML = `
                <tr><td colspan="${colSpan}" class="text-center h3 p-5">No Record Exist</td></tr>
            `;
            renderRecordPaginationUI(0, 1, 1);
            return;
        }

        // ---- Filter ----
        const filteredList = STATE.record.list.filter(record => {
            if (!filter) return true;
            return Object.values(record).some(val =>
                String(val).toLowerCase().includes(filter.toLowerCase())
            );
        });

        if (filteredList.length === 0) {
            tbody.innerHTML = `
                <tr><td colspan="${colSpan}" class="text-center h3 p-5">No Record Match</td></tr>
            `;
            renderRecordPaginationUI(0, 1, 1);
            return;
        }

        // ---- Pagination ----
        const pageSize = STATE.record.pagination.pageSize || 5;
        const { currentPage, totalPages, items, startIndex } = paginate(
            filteredList,
            STATE.record.pagination.currentPage,
            pageSize
        );
        STATE.record.pagination.currentPage = currentPage;

        // ---- Primary key column ----
        const pkColumn = columns.find(c => tableSchema.cols[c]?.primaryKey) || columns[0];

        // ---- Render rows ----
        tbody.innerHTML = items.map((record, idx) => {
            const displayIndex = startIndex + idx + 1;
            const recordId = record[pkColumn];

            const cells = columns.map(col => {
                const val = record[col];
                const displayVal = val === null || val === undefined ? "-" : String(val);
                return `<td>${escapeHTML(displayVal)}</td>`;
            }).join("");

            return `
                <tr>
                    <td>${displayIndex}</td>
                    ${cells}
                    <td class="d-flex gap-2">
                        <button class="btn btn-primary"
                            onclick="deleteRecord('${escapeHTML(tbName)}', '${escapeHTML(String(recordId))}')"
                            title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join("");

        renderRecordPaginationUI(filteredList.length, currentPage, totalPages);

    } catch (error) {
        console.error("Error rendering records:", error);
        tbody.innerHTML = `
            <tr><td colspan="3" class="text-center h3 p-5 text-danger">${escapeHTML(error.message)}</td></tr>
        `;
        renderRecordPaginationUI(0, 1, 1);
    }
}


// ============================================================
// PAGINATION UI — RECORD
// ============================================================

function renderRecordPaginationUI(totalItems, currentPage, totalPages) {
    const container = ELEMENT.mainTab.tabs.record.paginationContainer;
    if (!container) return;

    if (totalItems === 0) {
        container.innerHTML = `<span class="text-secondary fs-7">0 record</span>`;
        return;
    }

    const pageSize = STATE.record.pagination.pageSize;
    const startItem = (currentPage - 1) * pageSize + 1;
    const endItem   = Math.min(currentPage * pageSize, totalItems);

    container.innerHTML = `
        <span class="text-secondary fs-7">
            Menampilkan ${startItem} - ${endItem} dari ${totalItems} record
        </span>
        <div class="btn-group">
            <button class="btn btn-sm btn-secondary"
                ${currentPage === 1 ? "disabled" : ""}
                onclick="changeRecordPage(${currentPage - 1})">
                <i class="fas fa-chevron-left"></i> Prev
            </button>
            <span class="btn btn-sm btn-secondary disabled text-light">
                ${currentPage} / ${totalPages}
            </span>
            <button class="btn btn-sm btn-secondary"
                ${currentPage >= totalPages ? "disabled" : ""}
                onclick="changeRecordPage(${currentPage + 1})">
                Next <i class="fas fa-chevron-right"></i>
            </button>
        </div>
    `;
}

window.changeRecordPage = function(targetPage) {
    STATE.record.pagination.currentPage = targetPage;
    const filterValue = ELEMENT.mainTab.tabs.record.filterInput?.value || "";
    renderRecords(filterValue);
};


// ============================================================
// CREATE / DELETE — DATABASE
// ============================================================

window.createDatabase = createDatabase;

async function createDatabase() {
    try {
        const input = ELEMENT.mainTab.tabs.database.create.input;
        await LOIDA.database.create(input.value);
        input.value = "";
        await renderDatabaseList();
    } catch (error) {
        alert(error.message || error);
    }
}

window.deleteDatabase = deleteDatabase;

async function deleteDatabase(dbName) {
    if (!await confirm(`Delete database "${dbName}"?`)) return;

    try {
        await LOIDA.database.delete(dbName);
        await renderDatabaseList();
    } catch (error) {
        alert(error.message || error);
    }
}


// ============================================================
// CREATE / DELETE — TABLE
// ============================================================

window.deleteTable = deleteTable;

async function deleteTable(tbName) {
    if (!await confirm(`Delete table "${tbName}"?`)) return;

    try {
        const database = new LOIDA(STATE.database.name);
        await database.table.delete(tbName.split(".")[0]);
        await renderTableList(STATE.database.name);
    } catch (error) {
        alert(error.message || error);
    }
}


// ============================================================
// DELETE — RECORD
// ============================================================

window.deleteRecord = async function(tableName, recordId) {
    if (!await confirm("Delete this record?")) return;

    try {
        const database = new LOIDA(STATE.database.name);
        const tableSchema = await database.table.open(tableName);

        const pkColumn = Object.keys(tableSchema.cols).find(
            c => tableSchema.cols[c]?.primaryKey
        );

        if (!pkColumn) {
            alert("Cannot delete: No primary key defined.");
            return;
        }

        // Konversi tipe recordId sesuai tipe kolom PK
        const pkType = tableSchema.cols[pkColumn]?.type;
        let pkValue = recordId;
        if (pkType === "number" || pkType === "integer" || pkType === "float" || pkType === "double") {
            pkValue = Number(recordId);
        }

        await database.record.delete(tableName, {
            where: { [pkColumn]: pkValue }
        });

        await renderRecords();
    } catch (error) {
        alert(error.message || error);
    }
};


// ============================================================
// WINDOW
// ============================================================

window.openChild = openChild;

async function openChild(appPath) {
    try {
        SystemWindow.openAppWindow(__dirname + "/" + appPath, {
            name: "Loida Admin",
            child: true
        });
    } catch (error) {
        alert(error.message || error);
    }
}


// ============================================================
// EVENT LISTENERS — (dipasang SEKALI di luar fungsi)
// ============================================================

// ---- Database tab ----
ELEMENT.mainTab.tabs.database.filterInput?.addEventListener("input", (e) => {
    STATE.database.pagination.currentPage = 1;
    renderDatabaseList(e.target.value);
});

ELEMENT.mainTab.tabs.database.limitSelect?.addEventListener("change", (e) => {
    const val = e.target.value;
    STATE.database.pagination.pageSize = val === "all" ? 999999 : parseInt(val);
    STATE.database.pagination.currentPage = 1;
    renderDatabaseList(ELEMENT.mainTab.tabs.database.filterInput?.value || "");
});

// ---- Table tab ----
ELEMENT.mainTab.tabs.table.selectDB?.addEventListener("change", (e) => {
    STATE.database.name = e.target.value;
    renderTableList(e.target.value);
});

ELEMENT.mainTab.tabs.table.filterInput?.addEventListener("input", (e) => {
    STATE.table.pagination.currentPage = 1;
    renderTableList(STATE.database.name, e.target.value);
});

ELEMENT.mainTab.tabs.table.limitSelect?.addEventListener("change", (e) => {
    const val = e.target.value;
    STATE.table.pagination.pageSize = val === "all" ? 999999 : parseInt(val);
    STATE.table.pagination.currentPage = 1;
    renderTableList(STATE.database.name, ELEMENT.mainTab.tabs.table.filterInput?.value || "");
});

// ---- Record tab ----
ELEMENT.mainTab.tabs.record.select.database?.addEventListener("change", async (e) => {
    STATE.database.name = e.target.value;
    STATE.table.name = "";
    STATE.record.list = [];

    // Refresh dropdown table di record tab
    await renderTableList(e.target.value);

    // Render records dengan table pertama
    if (STATE.table.name) {
        renderRecords();
    } else {
        renderRecords();
    }
});

ELEMENT.mainTab.tabs.record.select.table?.addEventListener("change", (e) => {
    STATE.table.name = e.target.value;
    STATE.record.pagination.currentPage = 1;
    renderRecords();
});

ELEMENT.mainTab.tabs.record.filterInput?.addEventListener("input", (e) => {
    STATE.record.pagination.currentPage = 1;
    renderRecords(e.target.value);
});

ELEMENT.mainTab.tabs.record.limitSelect?.addEventListener("change", (e) => {
    const val = e.target.value;
    STATE.record.pagination.pageSize = val === "all" ? 999999 : parseInt(val);
    STATE.record.pagination.currentPage = 1;
    renderRecords(ELEMENT.mainTab.tabs.record.filterInput?.value || "");
});


// ============================================================
// INIT
// ============================================================

renderDatabaseList();