import Library from "./lib/Library.js";
import { SYSTEM } from "./global/state.js";

const { ipcRenderer } = require("electron");

async function renderWindow() {
    if (SYSTEM.ASSETS.FontAwesome) {
        Library.getSystemAsset("Font-Awesome-7.x", { 
            css: "css/all.css" 
        });
    }

    if (SYSTEM.ASSETS.Bootstrap) {        
        Library.getSystemAsset("Bootstrap-5.3.8-dist", { 
            css: "css/bootstrap.css", 
            js: "js/bootstrap.js" 
        });
    }
    
    if (SYSTEM.ASSETS.HighlightJS) {        
        Library.getSystemAsset("highlightjs", { 
            css: "vs2015.min.css", 
            js: "highlight.min.js" 
        });
    }

    await Library.importHTML(
        "./view/layouts/sidebar.html", 
        document.querySelector(".sidebar")
    );

    await Library.importHTML(
        "./view/layouts/app.html", 
        document.querySelector(".app")
    );
    
    
    
    await Library.importHTML(
        "./view/dialogs/create-table.html", 
        document.querySelector("create-table-dialog")
    );
    
    // await Library.importHTML(
    //     "./view/dialogs/inert-record.html", 
    //     document.querySelector("create-record-dialog")
    // );

    // setTitle("Application");
    
    const { default: OMX } = await Library.getSystemLibrary("omx/main.js");
    OMX.render();
}

renderWindow();

ipcRenderer.on("window-state", async (event, result) => {
    const { state } = result;

    const titleBar = Library.waitForElement(".title-bar");

    if (state === "focus") {
        titleBar.classList.remove("inactive");
    } else {
        titleBar.classList.add("inactive");
    }
});

let maximize = false;

window.titlebarControls = titlebarControls;

async function titlebarControls(option) {
    ipcRenderer.invoke("titlebar-controls", {
        method: option
    })
};