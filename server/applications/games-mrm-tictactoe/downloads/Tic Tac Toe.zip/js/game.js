const boardField = [
    document.getElementById("boardField0"),
    document.getElementById("boardField1"),
    document.getElementById("boardField2"),
    document.getElementById("boardField3"),
    document.getElementById("boardField4"),
    document.getElementById("boardField5"),
    document.getElementById("boardField6"),
    document.getElementById("boardField7"),
    document.getElementById("boardField8")
]

let state = [
    null, null, null,
    null, null, null,
    null, null, null
];

let turn = "x";

window.fillField = fillField;
function fillField(index) {

    
    if (state[index] !== null) {
        return;
    }
    
    boardField[index].innerHTML = `<i class="fas fa-${turn}"></i>`;
    
    state[index] = turn;

    setTimeout(() => {
        checkWin();
    }, 500)
    
    if (turn === "x") {
        turn = "o";
    } else {
        turn = "x";
    }

    const roleLabel     = document.getElementById("roleLabel");
    roleLabel.innerHTML = `<i class="fas fa-${turn}"></i>`;
}

function checkWin() {
    // X Win
    if (
        state[0] === "x" && state[1] === "x" && state[2] === "x" ||
        state[3] === "x" && state[4] === "x" && state[5] === "x" ||
        state[6] === "x" && state[7] === "x" && state[8] === "x" ||
    
        state[0] === "x" && state[3] === "x" && state[6] === "x" ||
        state[1] === "x" && state[4] === "x" && state[7] === "x" ||
        state[2] === "x" && state[5] === "x" && state[8] === "x" ||
    
        state[0] === "x" && state[4] === "x" && state[8] === "x" ||
        state[2] === "x" && state[4] === "x" && state[6] === "x" 
    ) {
        alert("X is Winner");
        newGame();
    }

    // O Win
    else if (
        state[0] === "o" && state[1] === "o" && state[2] === "o" ||
        state[3] === "o" && state[4] === "o" && state[5] === "o" ||
        state[6] === "o" && state[7] === "o" && state[8] === "o" ||
    
        state[0] === "o" && state[3] === "o" && state[6] === "o" ||
        state[1] === "o" && state[4] === "o" && state[7] === "o" ||
        state[2] === "o" && state[5] === "o" && state[8] === "o" ||
    
        state[0] === "o" && state[4] === "o" && state[8] === "o" ||
        state[2] === "o" && state[4] === "o" && state[6] === "o" 
    ) {
        alert("O is Winner");
        newGame();
    }

    // Tie
    if (
        state[0] === null || state[1] === null || state[2] === null ||
        state[3] === null || state[4] === null || state[5] === null ||
        state[6] === null || state[7] === null || state[8] === null
    ) {
        return;
    } else {
        alert("TIE");
        newGame();
    }
}

window.newGame = newGame;
function newGame() {
    for (let i = 0; i < 9; i++) {
        boardField[i].innerHTML = "";
        state[i] = null;
    }
}

document.addEventListener("keydown", (e) => {
    if (e.ctrlKey && (e.key === "n" || e.key === "N")) {
        newGame()
    }
})