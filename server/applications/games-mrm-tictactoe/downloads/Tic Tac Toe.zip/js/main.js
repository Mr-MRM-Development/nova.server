import "./setup.js";

import "./game.js"