const { ipcRenderer } = require("electron");
const path = require("path");

ipcRenderer.on("window-state", (event, result) => {
    if (result.state === "focus") {
        document.querySelector(".window").classList.add("active");
    } else {
        document.querySelector(".window").classList.remove("active");
    }
});

window.titlebarControls = titlebarControls;
function titlebarControls(method) {
    ipcRenderer.invoke("titlebar-controls", {
        method: method
    });
}

function addLink(result) {
    const link = document.createElement("link");
    link.rel   = result.rel;
    link.href  = result.href;

    document.head.appendChild(link)
}

addLink({
    rel: "stylesheet",
    href: path.join(process.cwd(), "drive/C/system/assets//Font-Awesome-7.x/css/all.css")
})