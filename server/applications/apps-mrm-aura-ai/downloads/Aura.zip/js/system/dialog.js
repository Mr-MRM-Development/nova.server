function showDialogModal(selector, options = {}) {
    const modalOverlay = document.querySelector(selector);
    if (!modalOverlay) {
        console.error(`Modal element dengan selector "${selector}" tidak ditemukan.`);
        return;
    }

    // Set judul jika diberikan di opsi
    if (options.title) {
        const titleElem = modalOverlay.querySelector('#modal-title');
        if (titleElem) titleElem.textContent = options.title;
    }

    // Set isi body jika diberikan di opsi
    if (options.body) {
        const bodyElem = modalOverlay.querySelector('#modal-body-content');
        if (bodyElem) bodyElem.innerHTML = options.body;
    }

    // Event handler tombol konfirmasi
    if (typeof options.onConfirm === 'function') {
        const confirmBtn = modalOverlay.querySelector('#modal-confirm-btn');
        if (confirmBtn) {
            // Hapus event listener lama agar tidak menumpuk
            const newConfirmBtn = confirmBtn.cloneNode(true);
            confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
            
            newConfirmBtn.addEventListener('click', () => {
                options.onConfirm();
                hideDialogModal(selector);
            });
        }
    }

    // Tampilkan modal
    modalOverlay.classList.add('active');
}

/**
 * Menutup Modal Dialog
 * @param {string} selector - Selector ID atau Class dari modal overlay
 */
function hideDialogModal(selector) {
    const modalOverlay = document.querySelector(selector);
    if (modalOverlay) {
        modalOverlay.classList.remove('active');
    }
}

function toggleDialogModal(selector) {
    const modalOverlay = document.querySelector(selector);
    if (modalOverlay) {
        modalOverlay.classList.toggle('active');
    }
}


export { showDialogModal, hideDialogModal, toggleDialogModal };

window.showDialogModal   = showDialogModal;
window.hideDialogModal   = hideDialogModal;
window.toggleDialogModal = toggleDialogModal;

// Inisialisasi event listener penutup (Tombol Red Light / Batal / Click Outside)
document.addEventListener('DOMContentLoaded', () => {
    // Tutup saat tombol .close-modal-btn diklik
    document.addEventListener('click', (e) => {
        if (e.target.closest('.close-modal-btn')) {
            const modalOverlay = e.target.closest('.modal-overlay');
            if (modalOverlay) {
                modalOverlay.classList.remove('active');
            }
        }
        
        // Tutup saat klik di luar area modal window (klik pada overlay)
        if (e.target.classList.contains('modal-overlay')) {
            e.target.classList.remove('active');
        }
    });
});