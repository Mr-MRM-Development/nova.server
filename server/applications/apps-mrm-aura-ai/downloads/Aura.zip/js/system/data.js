import FE from "../lib/FE.js";

class Data {
    static async readData(src) {
        const file = await FE.readFile(__dirname + "/data/" + src);
        return file.content;
    }
}

window.Data = Data;