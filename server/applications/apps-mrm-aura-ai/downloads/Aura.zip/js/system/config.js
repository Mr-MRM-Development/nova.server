const path = require("path");

const Configs = {
    Systems: {
        Assets: {
            FontAwesome: [true, { 
                uri: "Font-Awesome-7.x",
                css: "css/all.css",
            }],
            Bootstrap: [true, { 
                uri: "bootstrap-5.3.8-dist",
                css: "css/bootstrap.css",
                js:  "js/boottrap.js",
            }]
        }
    }
};

export default Configs