function changeTab(targetPageId, parentTabId, tabButtonSelector) {
    const container = document.querySelector(parentTabId);
    if (!container) return;

    // 1. Reset status 'active' pada semua tombol header
    const buttons = container.querySelectorAll('.tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));

    // 2. Sembunyikan semua halaman tab
    const pages = container.querySelectorAll('.tab-page');
    pages.forEach(page => page.classList.remove('active'));

    // 3. Tambahkan class 'active' pada tombol yang di-klik
    if (tabButtonSelector) {
        document.querySelector(tabButtonSelector).classList.add('active');
    } 
    else if (event && event.currentTarget) {
        event.currentTarget.classList.add('active');
    }

    // 4. Tampilkan halaman target
    const targetPage = container.querySelector(targetPageId);
    if (targetPage) {
        targetPage.classList.add('active');
    }
}

window.changeTab = changeTab;