import "./dialog.js"
import "./tab.js"
import "./data.js"