// utils/MarkdownParser.js

class MarkdownParser {
  /**
   * Mengubah teks markdown menjadi HTML.
   * Mendukung:
   * - heading (# s/d ######)
   * - bold, italic, bold-italic
   * - inline code (`...`)
   * - code block (```...```)
   * - link [teks](url)
   * - unordered list (-, *, +)
   * - ordered list (1. 2. dst)
   * - blockquote (>)
   * - tabel (pipe `|`)
   * - horizontal rule (---, ***, ___)
   * - line break
   *
   * @param {string} text
   * @returns {string}
   */
  static parse(text) {
    if (typeof text !== 'string' || !text) return '';

    // 1. Escape HTML dasar agar aman dari XSS
    let html = this.#escapeHtml(text);

    // 2. Code block (```...```) — diproses paling awal
    html = this.#parseCodeBlocks(html);

    // 3. Tabel
    html = this.#parseTables(html);

    // 4. Inline code (`...`)
    html = html.replace(/`([^`\n]+)`/g, '<code>$1</code>');

    // 5. Heading (# s/d ######)
    html = html.replace(/^######\s+(.+)$/gm, '<h6>$1</h6>');
    html = html.replace(/^#####\s+(.+)$/gm, '<h5>$1</h5>');
    html = html.replace(/^####\s+(.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^##\s+(.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^#\s+(.+)$/gm, '<h1>$1</h1>');

    // 6. Horizontal rule (---, ***, ___) minimal 3 karakter
    html = html.replace(/^(?:-{3,}|\*{3,}|_{3,})\s*$/gm, '<hr>');

    // 7. Blockquote
    html = html.replace(/^>\s?(.+)$/gm, '<blockquote>$1</blockquote>');

    // 8. Bold & italic (urutan penting)
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');
    html = html.replace(/_(.+?)_/g, '<em>$1</em>');

    // 9. Link [teks](url)
    html = html.replace(
      /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'
    );

    // 10. Unordered list (-, *, +)
    html = this.#convertList(html, /[\-\*\+]\s+(.+)/, 'ul');

    // 11. Ordered list (1. 2. dst)
    html = this.#convertList(html, /\d+\.\s+(.+)/, 'ol');

    // 12. Baris baru -> <br> (kecuali di dalam <pre> dan <table>)
    html = this.#applyLineBreaks(html);

    return html;
  }

  /**
   * Escape karakter HTML agar tidak diinterpretasi browser.
   */
  static #escapeHtml(text) {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /**
   * Mengubah code block ```...``` menjadi <pre><code>.
   */
  static #parseCodeBlocks(html) {
    return html.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
      const langClass = lang ? ` class="language-${lang}"` : '';
      return `<pre><code${langClass}>${code.replace(/\n$/, '')}</code></pre>`;
    });
  }

  /**
   * Mengubah tabel markdown menjadi <table>.
   *
   * Format yang didukung:
   * | Kolom 1 | Kolom 2 |
   * | ------- | ------- |
   * | isi 1   | isi 2   |
   */
  static #parseTables(html) {
    const lines = html.split('\n');
    const result = [];
    let i = 0;

    while (i < lines.length) {
      const headerLine = lines[i];
      const sepLine = lines[i + 1];

      const isHeader = /^\s*\|(.+)\|\s*$/.test(headerLine);
      const isSeparator =
        isHeader &&
        sepLine &&
        /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(sepLine);

      if (!isHeader || !isSeparator) {
        result.push(headerLine);
        i++;
        continue;
      }

      // Parse header
      const headers = this.#splitTableRow(headerLine);
      const aligns = this.#parseAlignments(sepLine);

      // Kumpulkan baris body
      const bodyRows = [];
      let j = i + 2;
      while (j < lines.length) {
        const rowLine = lines[j];
        if (!/^\s*\|(.+)\|\s*$/.test(rowLine)) break;
        bodyRows.push(this.#splitTableRow(rowLine));
        j++;
      }

      // Bangun HTML tabel
      const thead =
        '<thead><tr>' +
        headers
          .map((cell, idx) => {
            const align = aligns[idx] ? ` style="text-align:${aligns[idx]}"` : '';
            return `<th${align}>${cell}</th>`;
          })
          .join('') +
        '</tr></thead>';

      const tbody =
        '<tbody>' +
        bodyRows
          .map((cells) => {
            const tds = headers
              .map((_, idx) => {
                const cell = cells[idx] ?? '';
                const align = aligns[idx] ? ` style="text-align:${aligns[idx]}"` : '';
                return `<td${align}>${cell}</td>`;
              })
              .join('');
            return `<tr>${tds}</tr>`;
          })
          .join('') +
        '</tbody>';

      result.push(`<table>${thead}${tbody}</table>`);
      i = j;
    }

    return result.join('\n');
  }

  /**
   * Memecah satu baris tabel menjadi array sel.
   */
  static #splitTableRow(line) {
    return line
      .trim()
      .replace(/^\||\|$/g, '')
      .split('|')
      .map((cell) => cell.trim());
  }

  /**
   * Menentukan alignment tiap kolom dari baris separator.
   * Mengembalikan array berisi 'left' | 'center' | 'right' | null.
   */
  static #parseAlignments(sepLine) {
    return this.#splitTableRow(sepLine).map((cell) => {
      const left = cell.startsWith(':');
      const right = cell.endsWith(':');
      if (left && right) return 'center';
      if (right) return 'right';
      if (left) return 'left';
      return null;
    });
  }

  /**
   * Mengubah baris-baris yang cocok dengan pola list menjadi <ul>/<ol>.
   *
   * @param {string} html
   * @param {RegExp} pattern - Regex tanpa flag `g` (dipakai per baris).
   * @param {'ul'|'ol'} tag
   * @returns {string}
   */
  static #convertList(html, pattern, tag) {
    const source = pattern.source;
    const flags = pattern.flags.replace('g', '');
    const perLine = new RegExp(`^${source}$`, flags);

    const lines = html.split('\n');
    let result = '';
    let inList = false;

    for (const line of lines) {
      const replaced = line.replace(perLine, '<li>$1</li>');

      if (replaced !== line) {
        if (!inList) {
          result += `<${tag}>`;
          inList = true;
        }
        result += replaced;
      } else {
        if (inList) {
          result += `</${tag}>`;
          inList = false;
        }
        result += line + '\n';
      }
    }

    if (inList) result += `</${tag}>`;
    return result;
  }

  /**
   * Mengganti newline dengan <br>, tapi tidak di dalam <pre> dan <table>.
   */
  static #applyLineBreaks(html) {
    const parts = html.split(/(<pre[\s\S]*?<\/pre>|<table[\s\S]*?<\/table>)/g);
    return parts
      .map((part) => {
        if (part.startsWith('<pre') || part.startsWith('<table')) return part;
        return part
          .replace(/\n{2,}/g, '</p><p>')
          .replace(/\n/g, '<br>');
      })
      .join('');
  }
}

export default MarkdownParser;