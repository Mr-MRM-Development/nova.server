import Library from "../lib/Library.js";

import Elements from "../global/element.js";
import States    from "../global/state.js";

import ChatControllers from "./controllers/ChatControllers.js";


// const { chat, prompt } = Elements;

class App {
    constructor() {
        this.AIControllers = null;
        this.init();
    }

    async init() {
        this.ChatControllers = new ChatControllers();
    }

    async process() {
        
    }
}

const app = new App();
window.App = app;