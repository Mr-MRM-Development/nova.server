class AIControllers {
  constructor(options = {}) {
    this.baseUrl = options.baseUrl || 'https://api.ronz.qzz.io/ai';
    // memory menyimpan objek hasil respon AI sebelumnya
    this.memory = Array.isArray(options.initialMemory) ? [...options.initialMemory] : [];
  }

  getMemory() {
    return this.memory;
  }

  clearMemory() {
    this.memory = [];
  }
  pushMemory(item) {
    if (item === undefined || item === null) return;
    this.memory.push(typeof item === 'object' ? item : { respon_ai: String(item) });
  }

  #buildUrl(prompt) {
    const payload = {
      memory: this.memory,
      prompt,
    };
    const encoded = encodeURIComponent(JSON.stringify(payload));
    return `${this.baseUrl}?prompt=${encoded}`;
  }

  #extractResponse(data) {
    if (data == null) return '';
    if (typeof data === 'string') return data;
    if (typeof data === 'object') {
      if (typeof data.respon_ai === 'string') return data.respon_ai;
      if (typeof data.response === 'string') return data.response;
      if (typeof data.message === 'string') return data.message;
      if (typeof data.answer === 'string') return data.answer;
      try {
        return JSON.stringify(data);
      } catch {
        return String(data);
      }
    }
    return String(data);
  }

  async process(prompt) {
    // Kondisi 1: prompt kosong
    if (typeof prompt !== 'string' || prompt.trim() === '') {
      return {
        success: false,
        status: 'empty_prompt',
        message: 'Prompt tidak boleh kosong.',
        data: null,
        error: null,
        httpStatus: null,
        memory: this.getMemory(),
      };
    }

    const cleanPrompt = prompt.trim();

    try {
      const url = this.#buildUrl(cleanPrompt);
      const response = await fetch(url);

      // Kondisi 2: HTTP error (4xx / 5xx)
      if (!response.ok) {
        let errBody = null;
        try {
          errBody = await response.text();
        } catch {
          /* ignore */
        }
        return {
          success: false,
          status: 'http_error',
          message: `Server mengembalikan status ${response.status}.`,
          data: errBody,
          error: new Error(`HTTP ${response.status}`),
          httpStatus: response.status,
          memory: this.getMemory(),
        };
      }

      // Parsing body
      let data;
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        data = await response.json();
      } else {
        data = await response.text();
      }

      const aiText = this.#extractResponse(data);

      // Kondisi 3: respon kosong
      if (!aiText || !aiText.trim()) {
        return {
          success: false,
          status: 'empty_response',
          message: 'AI tidak mengembalikan jawaban.',
          data: null,
          error: null,
          httpStatus: response.status,
          memory: this.getMemory(),
        };
      }

      // Simpan ke memory — sesuai instruksi: memory.push(result.respon_ai)
      this.pushMemory({ respon_ai: aiText });

      // Kondisi 4: sukses
      return {
        success: true,
        status: 'success',
        message: aiText,
        data: aiText,
        error: null,
        httpStatus: response.status,
        memory: this.getMemory(),
      };
    } catch (err) {
      // Kondisi 5: network / fetch error
      const isAbort = err?.name === 'AbortError';
      return {
        success: false,
        status: isAbort ? 'aborted' : 'network_error',
        message: isAbort ? 'Permintaan dibatalkan.' : `Gagal terhubung ke server: ${err?.message || 'unknown error'}`,
        data: null,
        error: err instanceof Error ? err : new Error(String(err)),
        httpStatus: null,
        memory: this.getMemory(),
      };
    }
  }
}

export default AIControllers;