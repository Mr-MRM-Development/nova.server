class AIControllers {
  constructor(options = {}) {
    this.baseUrl = options.baseUrl || 'https://api.kilo.ai/api/gateway';
    this.model = options.model || 'kilo-auto/free';
    this.memory = Array.isArray(options.initialMemory) ? [...options.initialMemory] : [];
  }

  getMemory() {
    return this.memory;
  }

  clearMemory() {
    this.memory = [];
  }

  pushMemory(item) {
    if (item === undefined || item === null) return;
    this.memory.push(typeof item === 'object' ? item : { respon_ai: String(item) });
  }

  /**
   * Mengubah memory internal menjadi format messages OpenAI.
   */
  #buildMessages(prompt) {
    const history = this.memory.map((m) => ({
      role: 'assistant',
      content: m?.respon_ai ?? String(m),
    }));

    return [
      ...history,
      { role: 'user', content: prompt },
    ];
  }

  /**
   * Mengambil teks final dari respons API.
   * Prioritas: content -> reasoning -> fallback.
   */
  #extractContent(data) {
    if (data == null) return '';

    const message = data?.choices?.[0]?.message;

    if (typeof message?.content === 'string' && message.content.trim()) {
      return message.content;
    }

    if (typeof message?.reasoning === 'string' && message.reasoning.trim()) {
      return message.reasoning;
    }

    if (typeof data.respon_ai === 'string') return data.respon_ai;
    if (typeof data.response === 'string') return data.response;
    if (typeof data.message === 'string') return data.message;
    if (typeof data === 'string') return data;

    try {
      return JSON.stringify(data);
    } catch {
      return String(data);
    }
  }

  /**
   * Mengambil bagian reasoning mentah dari respons (jika ada).
   */
  #extractReasoning(data) {
    if (data == null) return null;
    const message = data?.choices?.[0]?.message;
    if (typeof message?.reasoning === 'string') return message.reasoning;
    return null;
  }

  /**
   * Memproses prompt ke API AI, menyimpan hasil ke memory,
   * lalu mengembalikan objek hasil sesuai kondisi.
   *
   * Struktur hasil:
   * {
   *   success: boolean,
   *   status: string,
   *   message: string,
   *   data: string | null,        // teks jawaban final
   *   reasoning: string | null,   // reasoning mentah (jika ada)
   *   content: string | null,     // konten mentah (jika ada)
   *   raw: object | string | null,// body respons asli
   *   error: Error | null,
   *   httpStatus: number | null,
   *   memory: Array,
   * }
   */
  async process(prompt, { signal } = {}) {
    // Kondisi 1: prompt kosong
    if (typeof prompt !== 'string' || prompt.trim() === '') {
      return {
        success: false,
        status: 'empty_prompt',
        message: 'Prompt tidak boleh kosong.',
        data: null,
        reasoning: null,
        content: null,
        raw: null,
        error: null,
        httpStatus: null,
        memory: this.getMemory(),
      };
    }

    const cleanPrompt = prompt.trim();

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.model,
          messages: this.#buildMessages(cleanPrompt),
        }),
        signal,
      });

      // Kondisi 2: HTTP error
      if (!response.ok) {
        let errBody = null;
        try {
          errBody = await response.text();
        } catch {
          // Abaikan
        }

        const isRateLimited = response.status === 429;
        return {
          success: false,
          status: 'http_error',
          message: isRateLimited
            ? 'Terlalu banyak permintaan. Batas sekitar 200 request per jam per IP. Coba lagi nanti.'
            : `Server mengembalikan status ${response.status}.`,
          data: null,
          reasoning: null,
          content: null,
          raw: errBody,
          error: new Error(`HTTP ${response.status}`),
          httpStatus: response.status,
          memory: this.getMemory(),
        };
      }

      // Parsing body
      let data;
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        data = await response.json();
      } else {
        data = await response.text();
      }

      const contentText = this.#extractContent(data);
      const reasoningText = this.#extractReasoning(data);

      // Kondisi 3: respons kosong
      if (!contentText || !contentText.trim()) {
        return {
          success: false,
          status: 'empty_response',
          message: 'AI tidak mengembalikan jawaban.',
          data: null,
          reasoning: reasoningText,
          content: null,
          raw: data,
          error: null,
          httpStatus: response.status,
          memory: this.getMemory(),
        };
      }

      // Simpan ke memory sebagai objek { respon_ai }
      this.pushMemory({ respon_ai: contentText });

      // Kondisi 4: sukses
      return {
        success: true,
        status: 'success',
        message: contentText,
        data: contentText,
        reasoning: reasoningText,
        content: contentText,
        raw: data,
        error: null,
        httpStatus: response.status,
        memory: this.getMemory(),
      };
    } catch (err) {
      // Kondisi 5: network / abort error
      const isAbort = err?.name === 'AbortError';
      return {
        success: false,
        status: isAbort ? 'aborted' : 'network_error',
        message: isAbort
          ? 'Permintaan dibatalkan.'
          : `Gagal terhubung ke server: ${err?.message || 'unknown error'}`,
        data: null,
        reasoning: null,
        content: null,
        raw: null,
        error: err instanceof Error ? err : new Error(String(err)),
        httpStatus: null,
        memory: this.getMemory(),
      };
    }
  }
}

export default AIControllers;