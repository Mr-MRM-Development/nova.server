import AIControllers  from './AIControllers.js';
import Elements       from '../../global/element.js';
import MarkdownParser from '../utils/MarkdownParser.js';

class ChatController {
  constructor() {
    this.ai = new AIControllers();
    this.isProcessing = false;
    this.#bindEvents();
  }

  /**
   * Memasang event listener pada input dan tombol.
   */
  #bindEvents() {
    Elements.prompt.button.addEventListener('click', () => this.#handleSend());

    Elements.prompt.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.#handleSend();
      }
    });

    // Auto-resize textarea saat user mengetik
    Elements.prompt.input.addEventListener('input', () => this.#autoResizeInput());
  }

  /**
   * Dipanggil dari luar (misalnya App.process()).
   *
   * @param {string} [text]
   * @returns {Promise<Object|null>}
   */
  async send(text) {
    return this.#handleSend(text);
  }

  /**
   * Handler saat user mengirim pesan.
   *
   * @param {string} [forcedText] - Jika diisi, abaikan nilai input.
   * @returns {Promise<Object|null>} Hasil dari AIControllers.process().
   */
  async #handleSend(forcedText) {
    if (this.isProcessing) return null;

    const raw = typeof forcedText === 'string' ? forcedText : Elements.prompt.input.value;
    const text = raw.trim();
    if (!text) return null;

    this.isProcessing = true;
    this.#setInputEnabled(false);

    this.#renderUserMessage(text);
    if (forcedText === undefined) {
      Elements.prompt.input.value = '';
      this.#autoResizeInput();
    }

    const typingEl = this.#renderTypingIndicator();
    let result = null;

    try {
      result = await this.ai.process(text);

      typingEl.remove();

      if (result.success) {
        this.#renderAIMessage(result.data);

        // Tampilkan reasoning jika ada dan berbeda dari data utama
        if (
          result.reasoning &&
          result.reasoning.trim() &&
          result.reasoning.trim() !== result.data?.trim()
        ) {
          this.#renderReasoning(result.reasoning);
        }
      } else {
        this.#renderAIMessage(result.message, { isError: true });
      }
    } catch (err) {
      typingEl.remove();
      this.#renderAIMessage(
        `Terjadi kesalahan tak terduga: ${err?.message || 'unknown error'}`,
        { isError: true }
      );
    } finally {
      this.isProcessing = false;
      this.#setInputEnabled(true);
      Elements.prompt.input.focus();
    }

    return result;
  }

  /**
   * Menampilkan pesan user di chat box.
   *
   * @param {string} text
   */
  #renderUserMessage(text) {
    const row = document.createElement('div');
    row.className = 'chat-row user';

    const bubble = document.createElement('div');
    bubble.className = 'chat-user';
    bubble.textContent = text;

    row.appendChild(bubble);
    Elements.chat.box.appendChild(row);
    this.#scrollToBottom();
  }

  /**
   * Menampilkan pesan AI di chat box.
   *
   * @param {string} text
   * @param {Object}  [options]
   * @param {boolean} [options.isError]
   * @param {boolean} [options.isMarkdown]
   */
  #renderAIMessage(text, { isError = false, isMarkdown = true } = {}) {
    const row = document.createElement('div');
    row.className = 'chat-row ai';

    const bubble = document.createElement('div');
    bubble.className = 'ai-chat';
    if (isError) bubble.classList.add('ai-error');

    if (isMarkdown && !isError) {
      bubble.innerHTML = MarkdownParser.parse(text);
    } else {
      bubble.textContent = text;
    }

    row.appendChild(bubble);
    Elements.chat.box.appendChild(row);
    this.#scrollToBottom();
  }

  /**
   * Menampilkan reasoning AI di dalam <details> agar tidak mengganggu.
   *
   * @param {string} text
   */
  #renderReasoning(text) {
    const row = document.createElement('div');
    row.className = 'chat-row ai';

    const details = document.createElement('details');
    details.className = 'ai-reasoning';

    const summary = document.createElement('summary');
    summary.textContent = 'Reasoning';

    const content = document.createElement('div');
    content.className = 'ai-reasoning-content';
    content.innerHTML = MarkdownParser.parse(text);

    details.appendChild(summary);
    details.appendChild(content);

    row.appendChild(details);
    Elements.chat.box.appendChild(row);
    this.#scrollToBottom();
  }

  /**
   * Menampilkan indikator "AI sedang mengetik".
   *
   * @returns {HTMLElement} elemen indikator agar bisa dihapus.
   */
  #renderTypingIndicator() {
    const row = document.createElement('div');
    row.className = 'chat-row ai';

    const bubble = document.createElement('div');
    bubble.className = 'ai-chat ai-typing';

    const dots = document.createElement('span');
    dots.className = 'typing-dots';
    dots.innerHTML = '<i></i><i></i><i></i>';

    bubble.appendChild(dots);
    row.appendChild(bubble);
    Elements.chat.box.appendChild(row);
    this.#scrollToBottom();

    return row;
  }

  /**
   * Mengaktifkan atau menonaktifkan input dan tombol.
   *
   * @param {boolean} enabled
   */
  #setInputEnabled(enabled) {
    Elements.prompt.input.disabled = !enabled;
    Elements.prompt.button.disabled = !enabled;
  }

  /**
   * Menyesuaikan tinggi textarea dengan isinya.
   */
  #autoResizeInput() {
    const input = Elements.prompt.input;
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 160)}px`;
  }

  /**
   * Scroll chat box ke bawah.
   */
  #scrollToBottom() {
    Elements.chat.box.scrollTop = Elements.chat.box.scrollHeight;
  }
}

export default ChatController;