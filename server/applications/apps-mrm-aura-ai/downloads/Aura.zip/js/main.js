import "./system/main.js";
import "./setup.js";
import "./app/main.js";
import Library from "./lib/Library.js";

window.Library = Library;