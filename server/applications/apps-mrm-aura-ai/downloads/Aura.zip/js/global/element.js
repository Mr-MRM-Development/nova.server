import Library from "../lib/Library.js";

const Elements = {
    prompt: {
        input: await Library.waitForElement("#prompt-input"),
        button: await Library.waitForElement("#prompt-button")
    },
    chat: {
        box: await Library.waitForElement("#chat-box")
    }
};

window.Elements = Elements;
export default Elements;