const States = {

};

window.States = States;
export default States;