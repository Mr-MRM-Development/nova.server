import Library from "../lib/Library.js";

const States = {
    
};

window.States = States;
export default States;