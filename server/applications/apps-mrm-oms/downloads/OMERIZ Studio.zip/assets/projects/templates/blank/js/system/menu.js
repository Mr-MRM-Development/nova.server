// ===== Menu: toggle buka/tutup dropdown =====
function toggleMenu(e) {
    e.stopPropagation();

    const btn = e.currentTarget;
    const parent = btn.parentElement; // .menu-item
    const hasDropdown = parent.querySelector(':scope > .dropdown');

    if (!hasDropdown) return;

    // Tutup semua .menu-item lain yang bukan parent ini (termasuk submenu)
    document.querySelectorAll('.menubar .menu-item.open').forEach(item => {
        if (item !== parent && !parent.contains(item)) {
            item.classList.remove('open');
        }
    });

    parent.classList.toggle('open');
}

// ===== Aksi menu (contoh) =====
function menuAction(name) {
    console.log('menu action:', name);
    closeAllMenus();
}

// ===== Tutup semua menu =====
function closeAllMenus() {
    document.querySelectorAll('.menubar .menu-item.open')
        .forEach(item => item.classList.remove('open'));
}

// ===== Klik di luar menutup menu =====
document.addEventListener('click', (e) => {
    if (!e.target.closest('.menubar')) {
        closeAllMenus();
    }
});

// ===== Expose ke window (karena type="module") =====
window.toggleMenu = toggleMenu;
window.menuAction = menuAction;
window.closeAllMenus = closeAllMenus;