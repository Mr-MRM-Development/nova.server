/**
 * |-------------------------------------------------------------|
 * |                                                             |
 * |         Standart OMERIZ Studio JavaScript Framework         |
 * |                                                             |
 * |-------------------------------------------------------------|
 * |         (C) 2026 | M. Rizqy Mubarok | OMERIZ Studio         |
 * |-------------------------------------------------------------|
 */

import Elements from "../global/element.js";
import States   from "../global/state.js";

import Library  from "../lib/Library.js";

class App {
    static async main() {
        
    }
}


window.App = App;
export { App };