const States = {
    editor: {
        language: "javascript",
        theme: "oneDark",
        line: 1,
        col: 1,
        filePath: null,
    },
    projects: {
        folderPath: null,
    },
    saved: {
        editor: ""
    },
    edit: {
        on: "code"
    }
};

window.States = States;
export default States;