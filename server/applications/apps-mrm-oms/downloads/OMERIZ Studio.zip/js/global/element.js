import Library from "../lib/Library.js";

const Elements = {
    editor: await Library.waitForElement(".editor"),
    toolbox: {
        body: await Library.waitForElement("#toolbox-body"),
    },
    frame: {
        main: await Library.waitForElement("#frame-main"),
        body: await Library.waitForElement("#frame-body")
    },
    properties: {
        body: await Library.waitForElement("#properties-body")
    },
    build: {
        body: await Library.waitForElement("#build-body")
    },

    library: {
        filter: await Library.waitForElement("#library-filter"),
        list: await Library.waitForElement("#library-list")
    }
};

window.Elements = Elements;
export default Elements;