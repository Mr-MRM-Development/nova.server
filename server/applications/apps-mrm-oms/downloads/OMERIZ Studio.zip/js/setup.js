const { ipcRenderer } = require("electron");

import Library from "./lib/Library.js";
import Configs from "./system/config.js";

ipcRenderer.on("maxStatus", (event, result) => {
    const { status } = result;

    const maxButton = document.getElementById("maxButton");

    if (status) {
        maxButton.textContent = "◱";
    } else {
        maxButton.textContent = "▢";
    }
})

ipcRenderer.on("window-state", (event, result) => {
    const { state } = result;

    const titleBar = document.querySelector(".title-bar");

    if (state === "focus") {
        titleBar.classList.remove("inactive");
    } else {
        titleBar.classList.add("inactive");
    }
})

let maximize = false;

window.titlebarControls = titlebarControls;

async function titlebarControls(option) {
    ipcRenderer.invoke("titlebar-controls", {
        method: option
    })
}

async function firstRender() {
    await Library.importHTML("./views/app.html", document.querySelector(".app"));
    await Library.importHTML("./views/tab.html", document.querySelector(".tab-zone"));
    await Library.importHTML("./views/menu.html", document.querySelector(".menu-bar"));
    await Library.importHTML("./views/sidebar.html", document.querySelector(".sidebar-content"));

    Object.entries(Configs.Systems.Assets).forEach(async (data) => {
        if (data[1][0]) {
            await Library.getSystemAsset(data[1][1].uri, {
                css: data[1][1].css,
                js:  data[1][1].js
            });
        }
    });
}

firstRender();