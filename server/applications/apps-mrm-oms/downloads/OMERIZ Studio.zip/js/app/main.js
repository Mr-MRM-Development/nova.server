// js/app/main.js
// OMERIZ Application Main
const { ipcRenderer } = require("electron");
const path            = require("path");

import { Editor } from "../vendor/editor/main.js";
import Elements from "../global/element.js";
import States from "../global/state.js";

import DialogSystem from "../lib/DialogSystem.js"
import SystemWindow from "../lib/SystemWindow.js"
import FE           from "../lib/FE.js"

import "./menu.js";

import ExplorerController    from "./controllers/ExplorerController.js";
import ToolboxController     from "./controllers/ToolboxController.js";
import VisualFrameController from "./controllers/VisualFrameController.js";
import BuildController       from "./controllers/BuildController.js";
import LibraryController     from "./controllers/LibraryController.js";

// ============================================================
// STATES
// ============================================================

States.editor = {
    language: "javascript",
    theme: "oneDark",
    line: 1,
    col: 1,
};


const Explorer  = new ExplorerController();
window.Explorer = Explorer;

const toolbox = new ToolboxController();
await toolbox.ready;

const frame = new VisualFrameController(toolbox, { debug: false });
const build = new BuildController(frame);
const libraryController = new LibraryController();

window.toolbox = toolbox;
window.frame = frame;
window.build = build;
window.libraryController = libraryController;


class App {
    static main() {
        try {
            Elements.editor = new Editor({
                parent: Elements.editor,
                doc: "",
                language: States.editor.language,
                theme: States.editor.theme,
                onCursor: ({ line, col }) => {
                    States.editor.line = line;
                    States.editor.col = col;
                }
            });

            States.saved.editor = Elements.editor.getValue();
            States.editor.lastChange = Date.now();

            // === FIX: pakai ResizeObserver, bukan onresize ===
            // Cari parent yang punya resize: both → .form-design
            const formDesign = Elements.frame.body.closest(".form-design") || document.querySelector(".form-design");

            if (formDesign) {
                const ro = new ResizeObserver((entries) => {
                    for (const entry of entries) {
                        const { width, height } = entry.contentRect;
                        App.updateSettings(width, height);
                    }
                });
                ro.observe(formDesign);

                // Simpan reference biar bisa di-disconnect nanti
                App._frameResizeObserver = ro;
            }
            // ===============================================

            // === Autosave dengan debounce ===
            let saveTimer = null;
            let isRemoteLoading = false;

            setInterval(async () => {
                if (!States.editor.filePath || isRemoteLoading) return;

                const currentValue = Elements.editor.getValue();
                const savedValue = States.saved.editor;

                // 1) Local → File (kalau berubah)
                if (currentValue !== savedValue) {
                    if (isRemoteLoading) return;
                    try {
                        await FE.writeFile(States.editor.filePath, currentValue);
                        States.saved.editor = currentValue;
                        States.editor.lastChange = Date.now();
                    } catch (e) {
                        console.warn("[autosave]", e.message);
                    }
                }

                // 2) File → Local (kalau ada perubahan dari luar)
                try {
                    const fileContent = (await FE.readFile(States.editor.filePath)).content;
                    if (fileContent !== savedValue && fileContent !== currentValue) {
                        isRemoteLoading = true;
                        Elements.editor.setValue(fileContent);
                        States.saved.editor = fileContent;
                        States.editor.lastChange = Date.now();
                        isRemoteLoading = false;
                    }
                } catch (e) {
                    // file belum ada / tidak bisa dibaca → skip
                }
            }, 2000); // ← 2 detik, bukan 1 detik
            // ===============================================

        } catch (error) {
            alert(error);
        }
    }

    static async runProject() {
        const rootPath = Explorer.explorer.getRoot();
        if (rootPath) {
            await this.build();
            await SystemWindow.openAppWindow(rootPath + "/index.html", {})
        }
    }

    static async compile() {
        if (States.projects.folderPath) {
            // alert(States.projects.folderPath);
            await this.build()
        }

        // const json = JSON.stringify(window.frame.getData(), null, 2);
        // alert(json);

        // const html = window.frame.compile();
        // alert(html);
    }

    static async build() {
        await changeTab('#editor-tab-1', '#editor-tab', '#editor-button-1');
        States.edit.on = 'design';

        await FE.writeFile(States.projects.folderPath + "/src/app.json", JSON.stringify(window.frame.getData(), null, 2));
        await FE.writeFile(States.projects.folderPath + "/views/app.html", 
            await window.frame.compileHTMLAsync({
                chunkSize: 50,
                onProgress: (done, total) => {
                    console.log(`Compile: ${done}/${total}`);
                }
            })
        );
    }

    static async load() {
        await changeTab('#editor-tab-1', '#editor-tab', '#editor-button-1');
        States.edit.on = 'design';

        await window.frame.setData(
            JSON.parse((await FE.readFile(States.projects.folderPath + "/src/app.json")).content)
        );

        const data = JSON.parse(
            (await FE.readFile(States.projects.folderPath + "/settings.json")).content
        );

        // Karena CSS sudah border-box, style.width = total
        Elements.frame.main.style.width  = data.width  + "px";
        Elements.frame.main.style.height = data.height + "px";

        // Update data.frame biar konsisten
        if (window.frame?.data?.frame) {
            window.frame.data.frame.width  = data.width;
            window.frame.data.frame.height = data.height;
        }
    }

    static async updateSettings() {
        if (!Elements.frame?.main) return;

        const w = Elements.frame.main.offsetWidth;   // ← TOTAL (border-box)
        const h = Elements.frame.main.offsetHeight;

        States.projects = States.projects || {};
        States.projects.frame = { width: w, height: h };

        if (window.frame?.data?.frame) {
            window.frame.data.frame.width  = w;
            window.frame.data.frame.height = h;
        }

        if (States.projects.folderPath && w > 0 && h > 0) {
            try {
                const content = (await FE.readFile(States.projects.folderPath + "/settings.json")).content;
                const data = JSON.parse(content);
                data.width  = w;
                data.height = h;
                await FE.writeFile(
                    States.projects.folderPath + "/settings.json",
                    JSON.stringify(data, null, 2)
                );
            } catch (e) {
                console.warn("[updateSettings]", e.message);
            }
        }
    }

    static async openProject() {
        const openDialog = await ipcRenderer.invoke("DialogSystem", {
            method: "openDialog",
            title: "Open your projects folder.",
            properties: ["openDirectory"]
        });

        if (openDialog.status === "success" && openDialog.path) {
            try {
                // States.project.path = openDialog.path;
                // alert(openDialog.path)

                States.projects.folderPath = String(openDialog.path);
                
                await Explorer.init();
                await Explorer.load(String(openDialog.path));
                await App.load();
            } catch (error) {
                alert(error)
            }
        }
    }
    
    static async newProject() {
        const saveDialog = await ipcRenderer.invoke("DialogSystem", {
            method: "saveDialog",
            title: "Select Your Project Destination.",
            properties: ["openDirectory"]
        });

        if (saveDialog.status === "success" && saveDialog.path) {
            try {
                // States.project.path = openDialog.path;
                // alert(openDialog.path)

                await FE.copyFile(
                    String(__dirname + "/assets/projects/templates/blank"),
                    String(path.dirname(saveDialog.path))
                );

                await FE.renameFile(
                    String(path.dirname(saveDialog.path) + "/blank"),
                    String(path.basename(saveDialog.path))
                );

                States.projects.folderPath = String(saveDialog.path);
                
                await Explorer.init();
                await Explorer.load(String(saveDialog.path));
                await App.load();
            } catch (error) {
                alert(error)
            }
        } else {
            alert(saveDialog.message)
        }
    }
}

App.main();
window.App = App;

export { App };