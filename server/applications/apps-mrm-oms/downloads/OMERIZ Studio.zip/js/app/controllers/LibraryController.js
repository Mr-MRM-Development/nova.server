import Library  from "../../lib/Library.js";
import FE       from "../../lib/FE.js";
import STATES   from "../../global/state.js";
import ELEMENTS from "../../global/element.js";

class LibraryController {
    constructor() {
        this.libraries = [];
        this.init();
    }

    async init() {
        await this.readLibrariesFolder();
        await this.renderList();
    }

    async readLibrariesFolder() {
        try {
            const result = await FE.readFolder(__dirname + "/assets/projects/src/libs");

            if (result.status === "success") {
                this.libraries = result.data;
                return this.libraries;
            }
        } catch (error) {
            alert("Error reading libraries folder:", error);
        }
    }

    async renderList(filter = "") {
        const listElement = ELEMENTS.library.list;
        listElement.innerHTML = "";

        this.libraries.forEach(library => {
            listElement.innerHTML += `<button onclick="libraryController.appendLibrary('${library}')">${library}</button>`
        });
    }

    async appendLibrary(name) {
        try {
            if (STATES.projects.folderPath) {
                await FE.copyFile(
                    __dirname + "/assets/projects/src/libs/" + name,
                    STATES.projects.folderPath + "/js/lib"
                );

                hideDialogModal('#library-dialog');

                Explorer.refresh();
            } else {
                alert("Please Open Your Project First.");
            }
        } catch (error) {
            alert(error);
        }
    }
}

export default LibraryController;