import Elements from "../../global/element.js";

import FE from "../../lib/FE.js";


class ToolboxController {

    constructor() {
        this.tools = [];
        this.ready = this.init();   // simpan promise biar bisa di-await dari luar
    }

    async init() {
        const response = await FE.readFile(__dirname + "/assets/toolbox/main.json");

        if (response.status === "success") {
            this.tools = JSON.parse(response.content);
    
            this.render();
    
            return this.tools;
        } else {
            throw new Error(`Gagal memuat toolbox: ${response.status}`);
        }

    }

    render() {
        const toolboxBody = Elements.toolbox?.body;

        if (!toolboxBody) {
            console.error("[Toolbox] Elements.toolbox.body tidak ditemukan.");
            return;
        }

        toolboxBody.innerHTML = "";

        const fragment = document.createDocumentFragment();

        this.tools.forEach(tool => {
            const button = document.createElement("button");
            button.className        = "tool btn btn-secondary text-light";
            button.style.textAlign  = "left";
            button.style.background = "var(--primary-2)";
            button.style.border     = "none";
            button.style.cursor     = "grab";
            button.dataset.tool     = tool.name;
            button.draggable        = true;

            button.innerHTML = `
                <i class="${tool.icon}"></i>
                <span>${tool.title}</span>
            `;

            button.addEventListener("dragstart", event => {
                event.dataTransfer.setData("tool", tool.name);
                event.dataTransfer.effectAllowed = "copy";
            });

            fragment.appendChild(button);
        });

        toolboxBody.appendChild(fragment);
    }

    getTools() {
        return this.tools;
    }

    getTool(name) {
        return this.tools.find(tool => tool.name === name) || null;
    }
}

export default ToolboxController;