const path = require("path");

import Library from "../../lib/Library.js";
import Explorer from "../../lib/Explorer.js";
import FE from "../../lib/FE.js";

import Elements from "../../global/element.js";
import States   from "../../global/state.js";

class ExplorerController {

    constructor() {
        this.explorer = new Explorer();
        this.treeview = null;

        this.subFolder = "";

        this.controls = {
            refresh: null,
            makeFolder: null,
            makeFile: null,
            collapseAll: null
        };

        this.popup = {
            element: null,
            title: null,
            label: null,
            input: null,
            close: null,
            cancel: null,
            create: null,
            type: null
        };

        this.init();
    }

    async init() {
        this.treeview = await Library.waitForElement("#explorer-treeview");

        this.initControls();
        this.initPopup();

        return this.treeview;
    }

    async load(rootPath) {
        if (!this.treeview) {
            await this.init();
        }

        rootPath = String(rootPath);

        this.explorer.setRoot(rootPath);

        const tree = await this.explorer.load();

        this.render(tree);

        return tree;
    }

    async refresh() {
        const rootPath = String(this.explorer.getRoot());

        if (!rootPath || rootPath === "null") {
            throw new Error("Explorer belum memiliki root folder.");
        }

        const tree = this.explorer.getTree();

        if (!tree) {
            return this.load(rootPath);
        }

        await this.#refreshFolder(tree);

        return tree;
    }

    async makeFolder(name, parentPath = this.explorer.getCurrentPath() + "/" + this.subFolder) {
        if (!name) {
            return;
        }

        if (!parentPath) {
            throw new Error("Folder tujuan tidak ditemukan.");
        }

        parentPath = String(parentPath);

        const folderPath = String(path.join(parentPath, String(name)));

        const result = await FE.makeFolder(String(parentPath).replace(/\\/g, "\/"), String(name));

        // if (result.status === "error") {
        //     throw new Error(result?.message || "Gagal membuat folder.");
        // }

        await this.refresh();

        return String(folderPath);
    }

    async makeFile(name, parentPath = this.explorer.getCurrentPath() + "/" + this.subFolder) {
        if (!name) {
            return;
        }

        if (!parentPath) {
            throw new Error("Folder tujuan tidak ditemukan.");
        }

        parentPath = String(parentPath);

        const filePath = String(path.join(parentPath, String(name)));

        const result = await FE.writeFile(String(filePath), "");

        if (!result || result.status !== "success") {
            throw new Error(result?.message || "Gagal membuat file.");
        }

        await this.refresh();

        return String(filePath);
    }

    initControls() {
        this.controls.refresh = document.querySelector("#explorer-refresh");
        this.controls.makeFolder = document.querySelector("#explorer-make-folder");
        this.controls.makeFile = document.querySelector("#explorer-make-file");
        this.controls.collapseAll = document.querySelector("#explorer-collapse-all");

        this.controls.refresh?.addEventListener("click", async () => {
            try {
                await this.refresh();
            } catch (error) {
                console.error(error);
                alert(error.message);
            }
        });

        this.controls.makeFolder?.addEventListener("click", () => {
            this.openPopup("folder");
        });

        this.controls.makeFile?.addEventListener("click", () => {
            this.openPopup("file");
        });

        this.controls.collapseAll?.addEventListener("click", () => {
            this.collapseAll();
        });
    }

    initPopup() {
        this.popup.element = document.querySelector("#explorer-popup");
        this.popup.title   = document.querySelector("#explorer-popup-title");
        this.popup.label   = document.querySelector("#explorer-popup-label");
        this.popup.input   = document.querySelector("#explorer-popup-input");
        this.popup.close   = document.querySelector("#explorer-popup-close");
        this.popup.cancel  = document.querySelector("#explorer-popup-cancel");
        this.popup.create  = document.querySelector("#explorer-popup-create");

        this.popup.close?.addEventListener("click", () => {
            this.closePopup();
        });

        this.popup.cancel?.addEventListener("click", () => {
            this.closePopup();
        });

        this.popup.create?.addEventListener("click", async () => {
            await this.submitPopup();
        });

        this.popup.input?.addEventListener("keydown", async event => {
            if (event.key === "Enter") {
                await this.submitPopup();
            }

            if (event.key === "Escape") {
                this.closePopup();
            }
        });

        this.popup.element?.querySelector(".explorer-popup-backdrop")?.addEventListener("click", () => {
            this.closePopup();
        });
    }

    openPopup(type) {
        if (!this.popup.element) {
            return;
        }

        this.popup.type = type;

        if (type === "folder") {
            this.popup.title.textContent = "New Folder";
            this.popup.label.textContent = "Folder Name";
            this.popup.input.placeholder = "example";
        }

        if (type === "file") {
            this.popup.title.textContent = "New File";
            this.popup.label.textContent = "File Name";
            this.popup.input.placeholder = "example.js";
        }

        this.popup.input.value = "";

        this.popup.element.classList.add("open");

        requestAnimationFrame(() => {
            this.popup.input.focus();
        });
    }

    closePopup() {
        this.popup.element?.classList.remove("open");
        this.popup.type = null;
    }

    async submitPopup() {
        const name = this.popup.input?.value.trim();

        if (!name) {
            this.popup.input?.focus();
            return;
        }

        try {
            if (this.popup.type === "folder") {
                await this.makeFolder(String(name));
            }

            if (this.popup.type === "file") {
                await this.makeFile(String(name));
            }

            this.closePopup();

        } catch (error) {
            console.error(error);
            alert(error.message);
        }
    }

    collapseAll() {
        if (!this.treeview) {
            return;
        }

        this.treeview.querySelectorAll(".tree-folder").forEach(folder => {
            // Skip root
            if (folder.classList.contains("tree-root")) {
                return;
            }

            folder.classList.remove("open");

            const toggle = folder.querySelector(":scope > .tree-item > .tree-toggle");
            const children = folder.querySelector(":scope > .tree-children");
            const icon = toggle?.querySelector("i");

            if (toggle) {
                toggle.setAttribute("aria-expanded", "false");
            }

            if (children) {
                children.style.display = "none";
            }

            if (icon) {
                icon.className = "fa-solid fa-chevron-right";
            }
        });
    }

    render(tree = this.explorer.getTree()) {
        if (!this.treeview) {
            throw new Error("TreeView belum diinisialisasi.");
        }

        this.treeview.innerHTML = "";

        if (!tree) {
            return;
        }

        this.treeview.appendChild(this.#createFolder(tree, true));
    }

    async #refreshFolder(folder) {
        const folderPath = String(folder.path);
        const items = await this.explorer.loadFolder(folderPath);
        const oldChildren = folder.children || [];

        const childrenMap = new Map();

        for (const child of oldChildren) {
            childrenMap.set(String(child.path), child);
        }

        folder.children = items.map(item => {
            const itemPath = String(item.path);
            const oldItem = childrenMap.get(itemPath);

            if (!oldItem) {
                return item;
            }

            oldItem.name = item.name;
            oldItem.path = itemPath;
            oldItem.type = item.type;
            oldItem.extension = item.extension;

            if (item.type === "folder") {
                oldItem.children = oldItem.children || [];
                oldItem.loaded = oldItem.loaded === true;
            }

            return oldItem;
        });

        const folderElement = this.#findFolderElement(folderPath);

        if (!folderElement) {
            return;
        }

        const children = folderElement.querySelector(":scope > .tree-children");

        if (!children) {
            return;
        }

        this.#syncFolderChildren(folder, children);

        for (const child of folder.children) {
            if (child.type !== "folder" || !child.loaded) {
                continue;
            }

            await this.#refreshFolder(child);
        }
    }

    #syncFolderChildren(folder, childrenElement) {
        const existing = new Map();

        for (const element of childrenElement.children) {
            const elementPath = String(element.dataset.path || "");

            if (elementPath) {
                existing.set(elementPath, element);
            }
        }

        const fragment = document.createDocumentFragment();
        const folderItems = [];
        const fileItems = [];

        for (const child of folder.children || []) {
            if (child.type === "folder") folderItems.push(child);
            else if (child.type === "file") fileItems.push(child);
        }

        // === Loop 1: FOLDER DULU ===
        for (const child of folderItems) {
            const childPath = String(child.path);
            const element = existing.get(childPath);

            if (element) {
                this.#updateFolderElement(element, child);
                existing.delete(childPath);
                fragment.appendChild(element);
                continue;
            }

            fragment.appendChild(this.#createFolder(child));
        }

        // === Loop 2: FILE BARU ===
        for (const child of fileItems) {
            const childPath = String(child.path);
            const element = existing.get(childPath);

            if (element) {
                this.#updateFileElement(element, child);
                existing.delete(childPath);
                fragment.appendChild(element);
                continue;
            }

            fragment.appendChild(this.#createFile(child));
        }

        // Hapus elemen yang sudah tidak ada di data
        for (const element of existing.values()) {
            element.remove();
        }

        childrenElement.appendChild(fragment);
    }

    #findFolderElement(folderPath) {
        folderPath = String(folderPath);

        if (!this.treeview) {
            return null;
        }

        const folders = this.treeview.querySelectorAll(".tree-folder");

        for (const folder of folders) {
            if (String(folder.dataset.path) === folderPath) {
                return folder;
            }
        }

        return null;
    }

    #updateFolderElement(element, folder) {
        element.dataset.path = String(folder.path);

        const name = element.querySelector(":scope > .tree-item > .tree-name");

        if (name) {
            name.textContent = folder.name;
        }
    }

    #updateFileElement(element, file) {
        element.dataset.path = String(file.path);

        const name = element.querySelector(":scope > .tree-item > .tree-name");

        if (name) {
            name.textContent = file.name;
        }

        const icon = element.querySelector(":scope > .tree-item > .tree-icon");

        if (icon) {
            icon.className = `${this.#getFileIcon(file.extension)} tree-icon`;
        }
    }

    #createFolder(folder, isRoot = false) {
        const li = document.createElement("li");

        li.className = "tree-folder";
        li.dataset.path = String(folder.path);

        const item = document.createElement("div");

        item.className = "tree-item";

        // Root: tidak ada toggle
        let toggle = null;
        let icon = null;

        if (!isRoot) {
            toggle = document.createElement("button");
            toggle.className = "tree-toggle";
            toggle.type = "button";
            toggle.setAttribute("aria-expanded", "false");

            icon = document.createElement("i");
            icon.className = "fa-solid fa-chevron-right";

            toggle.appendChild(icon);
        }

        const label = document.createElement("span");

        label.className = "tree-name";
        label.textContent = folder.name;

        if (toggle) {
            item.appendChild(toggle);
        }
        item.appendChild(label);

        const children = document.createElement("ul");

        children.className = "tree-children";

        for (const child of folder.children || []) {
            if (child.type === "folder") {
                children.appendChild(this.#createFolder(child));
                continue;
            }
        }

        for (const child of folder.children || []) {
            if (child.type === "file") {
                children.appendChild(this.#createFile(child));
                continue;
            }
        }

        // Root: langsung terbuka, tidak ada toggle klik
        if (isRoot) {
            li.classList.add("open", "tree-root");
            children.style.display = "block";
        } else {
            children.style.display = "none";

            item.addEventListener("click", async event => {
                this.subFolder = folder.path.replace(this.explorer.getCurrentPath(), "").replace(/^\//, "");
                event.stopPropagation();

                const expanded = toggle.getAttribute("aria-expanded") === "true";

                if (expanded) {
                    this.#setFolderState(li, children, toggle, icon, false);
                    return;
                }

                try {
                    if (!folder.loaded) {
                        await this.#loadFolder(folder, children);
                    }

                    this.#setFolderState(li, children, toggle, icon, true);

                } catch (error) {
                    console.error(error);
                    alert(error.message);
                }
            });
        }

        li.appendChild(item);
        li.appendChild(children);

        return li;
    }

    async #loadFolder(folder, children) {
        const folderPath = String(folder.path);

        const items = await this.explorer.loadFolder(folderPath);

        folder.path = String(folder.path);
        folder.children = items;
        folder.loaded = true;

        children.innerHTML = "";

        for (const child of items) {
            if (child.type === "folder") {
                children.appendChild(this.#createFolder(child));
                continue;
            }
        }

        for (const child of items) {
            if (child.type === "file") {
                children.appendChild(this.#createFile(child));
                continue;
            }
        }
    }

    #setFolderState(li, children, toggle, icon, expanded) {
        li.classList.toggle("open", expanded);
        toggle.setAttribute("aria-expanded", String(expanded));
        children.style.display = expanded ? "block" : "none";
    }

    #createFile(file) {
        const li = document.createElement("li");

        li.className = "tree-file";
        li.dataset.path = String(file.path);

        const item = document.createElement("button");

        item.className = "tree-item";
        item.type = "button";

        const icon = document.createElement("i");

        icon.className = `${this.#getFileIcon(file.extension)} tree-icon`;

        const label = document.createElement("span");

        label.className = "tree-name";
        label.textContent = file.name;

        item.appendChild(icon);
        item.appendChild(label);

        item.addEventListener("click", async () => {
            this.select(file, li);

            this.subFolder = path.dirname(file.path.replace(this.explorer.getCurrentPath(), "").replace(/^\//, ""));

            const Editor = Elements.editor;

            if (!Editor) {
                console.error("Editor belum diinisialisasi.");
                return;
            }

            try {
                const filePath = String(file.path);
                const data = await FE.readFile(filePath);
                States.editor.filePath = filePath;

                if (!data || data.status !== "success") {
                    throw new Error(data?.message || "Gagal membaca file.");
                }

                if (file.extension === ".html") {
                    Editor.setLanguage("html");
                }
                else if (file.extension === ".css") {
                    Editor.setLanguage("css");
                }
                else if (file.extension === ".json") {
                    Editor.setLanguage("json");
                }
                else if (file.extension === ".js") {
                    Editor.setLanguage("javascript");
                }

                Editor.setValue(data.content);
                Editor.focus();

            } catch (error) {
                console.error(error);
                alert(error.message);
            }
        });

        li.appendChild(item);

        return li;
    }

    select(file, element = null) {
        this.explorer.select(file);

        this.treeview?.querySelectorAll(".tree-file.selected").forEach(item => {
            item.classList.remove("selected");
        });

        if (element) {
            element.classList.add("selected");
        }

        return file;
    }

    #getFileIcon(extension) {
        const icons = {
            ".js": "fa-brands fa-js",
            ".json": "fa-solid fa-code",
            ".html": "fa-brands fa-html5",
            ".css": "fa-brands fa-css3-alt",
            ".md": "fa-solid fa-file-lines",
            ".txt": "fa-solid fa-file-lines",
            ".png": "fa-solid fa-file-image",
            ".jpg": "fa-solid fa-file-image",
            ".jpeg": "fa-solid fa-file-image",
            ".gif": "fa-solid fa-file-image",
            ".svg": "fa-solid fa-file-image",
            ".zip": "fa-solid fa-file-zipper",
            ".exe": "fa-solid fa-file",
            ".mapp": "fa-solid fa-cube"
        };

        return icons[extension] || "fa-solid fa-file";
    }

    getExplorer() {
        return this.explorer;
    }

    getTreeView() {
        return this.treeview;
    }

    getControls() {
        return this.controls;
    }

    getPopup() {
        return this.popup;
    }

}

export default ExplorerController;