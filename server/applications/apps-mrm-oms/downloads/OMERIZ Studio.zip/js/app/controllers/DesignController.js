import Elements from "../../global/element.js";
import States   from "../../global/state.js";

import Library  from "../../lib/Library.js";


class DesignController {

    constructor(toolbox = null) {
        this.toolbox = toolbox;
        this.frame = null;
        this.elements = [];

        this.init();
    }

    async init() {
        this.frame = Elements.design.body;

        if (!this.frame) {
            throw new Error("Elements.design.body tidak ditemukan.");
        }

        this.bindEvents();
    }

    bindEvents() {
        this.frame.addEventListener("dragover", event => {
            event.preventDefault();
        });

        this.frame.addEventListener("drop", event => {
            event.preventDefault();

            const name = event.dataTransfer.getData("tool");

            if (!name) {
                return;
            }

            const tool = this.toolbox?.getTool(name);

            if (!tool) {
                return;
            }

            this.create(tool, event);
        });
    }

    create(tool, event = null) {
        const element = this.createElement(tool);

        if (!element) {
            return null;
        }

        this.frame.appendChild(element);

        this.elements.push(element);

        this.setPosition(element, event);

        return element;
    }

    createElement(tool) {
        const wrapper = document.createElement("div");

        wrapper.innerHTML = tool.tag;

        const element = wrapper.firstElementChild;

        if (!element) {
            throw new Error(`Tag tool "${tool.name}" tidak valid.`);
        }

        element.dataset.tool = tool.name;
        element.dataset.id = this.createId();

        this.applyDefault(element, tool.default);

        return element;
    }

    applyDefault(element, defaults = {}) {
        if (defaults.style) {
            Object.entries(defaults.style).forEach(([property, value]) => {
                element.style[property] = `${value}px`;
            });
        }

        if (defaults.textContent !== undefined) {
            element.textContent = defaults.textContent;
        }
    }

    setPosition(element, event = null) {
        if (!event) {
            element.style.left = "0px";
            element.style.top = "0px";
            return;
        }

        const rect = this.frame.getBoundingClientRect();

        element.style.left = `${event.clientX - rect.left}px`;
        element.style.top = `${event.clientY - rect.top}px`;
    }

    createId() {
        return `element-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    }

    getElements() {
        return this.elements;
    }

    getElement(id) {
        return this.elements.find(element => element.dataset.id === id) || null;
    }

}

export default DesignController;