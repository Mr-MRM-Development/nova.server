class BuildController {

    constructor(visualFrame, options = {}) {
        this.visualFrame = visualFrame;
        this.body = null;
        this.debug = options.debug ?? false;

        // UI (opsional)
        this.mode = "data";     // "data" | "html"
        this.currentData = null;
        this.currentHTML = "";

        // Kalau mau ada panel UI
        if (options.mount !== false) this.init();
    }

    // =====================================================
    // INIT (opsional — kalau mau panel UI)
    // =====================================================
    async init() {
        this.body = Elements.build?.body || await Library.waitForElement("#build-body");
        if (!this.body) return console.warn("[Build] #build-body tidak ada");

        this.bindUI();
        this.refresh();
    }

    bindUI() {
        // (sama seperti sebelumnya — toolbar + iframe/textarea)
    }

    // =====================================================
    // CORE: DATA ⇄ HTML
    // =====================================================

    // ---- Data → HTML (fragment, tanpa wrapper) ----
    dataToHTML(data = null) {
        const source = data || this.visualFrame?.getData();
        if (!source?.elements) return "";

        return source.elements
            .map(el => this.elementToHTML(el))
            .join("");
    }

    elementToHTML(el) {
        const element = el.element || {};
        const visual = el.visual || {};
        const tag = element.tag || "div";

        // Attributes
        const attrs = { ...(element.attributes || {}) };

        // Class — bersih
        if (element.class) {
            const clean = element.class
                .split(/\s+/)
                .filter(c => c && c !== "selected" && c !== "vf-dragging" && !c.startsWith("vf-handle"))
                .join(" ");
            if (clean) attrs.class = clean;
        }

        // value/src/href
        if (element.value !== undefined) attrs.value = element.value;
        if (element.src !== undefined) attrs.src = element.src;
        if (element.href !== undefined) attrs.href = element.href;

        // Style — dari element.style + visual
        const style = { ...(element.style || {}) };
        if (visual.x !== undefined) style.left = `${visual.x}px`;
        if (visual.y !== undefined) style.top = `${visual.y}px`;
        if (visual.width !== undefined) style.width = `${visual.width}px`;
        if (visual.height !== undefined) style.height = `${visual.height}px`;
        style.position = "absolute";

        attrs.style = this.styleToString(style);

        // Content
        const isVoid = this.isVoidElement(tag);
        const content = isVoid ? "" : (element.textContent ?? "");

        // Children (kalau ada nesting)
        const childrenHTML = Array.isArray(el.children)
            ? el.children.map(c => this.elementToHTML(c)).join("")
            : "";

        // Render
        const attrStr = this.attrsToString(attrs);

        if (isVoid) return `<${tag}${attrStr}>`;
        return `<${tag}${attrStr}>${this.escapeHTML(content)}${childrenHTML}</${tag}>`;
    }

    // ---- HTML → Data ----
    htmlToData(html) {
        if (!html || typeof html !== "string") {
            return { version: 1, type: "visual-frame", frame: { width: 800, height: 600 }, elements: [] };
        }

        // Pakai template biar aman
        const tpl = document.createElement("template");
        tpl.innerHTML = html.trim();

        const elements = [];

        Array.from(tpl.content.children).forEach(child => {
            const data = this.elementToData(child);
            if (data) elements.push(data);
        });

        return {
            version: 1,
            type: "visual-frame",
            frame: this.visualFrame?.data?.frame || { width: 800, height: 600 },
            elements
        };
    }

    elementToData(el) {
        const tag = el.tagName.toLowerCase();

        // ---- Parsing style ----
        const styleObj = {};
        const visual = { x: 0, y: 0, width: 100, height: 30 };

        Array.from(el.style).forEach(prop => {
            const value = el.style[prop];
            if (!value) return;

            if (prop === "left")   { visual.x = parseFloat(value) || 0; return; }
            if (prop === "top")    { visual.y = parseFloat(value) || 0; return; }
            if (prop === "width")  { visual.width = parseFloat(value) || 100; return; }
            if (prop === "height") { visual.height = parseFloat(value) || 30; return; }
            if (prop === "position") return; // skip

            styleObj[prop] = value;
        });

        // ---- Attributes ----
        const attributes = {};
        let className = "";
        let value, src, href;

        Array.from(el.attributes).forEach(attr => {
            const name = attr.name;
            const val = attr.value;

            if (name === "class") { className = val; return; }
            if (name === "style") return;
            if (name === "value") { value = val; return; }
            if (name === "src") { src = val; return; }
            if (name === "href") { href = val; return; }

            attributes[name] = val;
        });

        // ---- Content ----
        const isVoid = this.isVoidElement(tag);
        let textContent;

        if (!isVoid) {
            // Ambil text langsung (bukan dari children)
            textContent = "";
            Array.from(el.childNodes).forEach(node => {
                if (node.nodeType === 3) textContent += node.nodeValue;
            });
        }

        // ---- Children ----
        const children = [];
        Array.from(el.children).forEach(child => {
            const childData = this.elementToData(child);
            if (childData) children.push(childData);
        });

        // ---- Bangun data ----
        const data = {
            id: this.createId(),
            tool: this.inferTool(className, tag),
            visual,
            element: {
                tag,
                class: className,
                style: styleObj,
                attributes,
                ...(isVoid ? {} : { textContent }),
                ...(value !== undefined ? { value } : {}),
                ...(src !== undefined ? { src } : {}),
                ...(href !== undefined ? { href } : {})
            },
            compile: {
                tag,
                attributes: { ...attributes, ...(className ? { class: className } : {}) },
                content: textContent || "",
                children: children.map(c => c.compile)
            }
        };

        // Simpan children di data (untuk nesting nanti)
        if (children.length) data.children = children;

        return data;
    }

    // ---- Load HTML → frame ----
    loadHTML(html) {
        const data = this.htmlToData(html);
        this.visualFrame?.setData(data);
        return data;
    }

    // ---- Get HTML dari frame ----
    getHTML() {
        return this.dataToHTML();
    }

    // ---- Round-trip: frame → HTML → frame ----
    roundTrip() {
        const html = this.getHTML();
        const data = this.htmlToData(html);
        this.visualFrame?.setData(data);
        return { html, data };
    }

    // =====================================================
    // HELPERS
    // =====================================================
    attrsToString(attrs) {
        return Object.entries(attrs)
            .filter(([_, v]) => v !== undefined && v !== null && v !== "")
            .map(([name, value]) => ` ${name}="${this.escapeAttr(value)}"`)
            .join("");
    }

    styleToString(style) {
        return Object.entries(style)
            .filter(([_, v]) => v !== undefined && v !== null && v !== "")
            .map(([k, v]) => {
                const prop = k.replace(/[A-Z]/g, m => `-${m.toLowerCase()}`);
                return `${prop}:${v}`;
            })
            .join(";");
    }

    isVoidElement(tag) {
        return [
            "area", "base", "br", "col", "embed", "hr", "img",
            "input", "link", "meta", "param", "source", "track", "wbr"
        ].includes(String(tag).toLowerCase());
    }

    escapeHTML(v) {
        return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    escapeAttr(v) {
        return String(v).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    inferTool(className, tag) {
        // Coba tebak dari class "type-X"
        const m = className?.match(/type-([a-z0-9-]+)/i);
        if (m) return m[1];

        // Fallback ke tag
        const map = { button: "button", input: "input", textarea: "textarea", a: "link", img: "image", h1: "heading", h2: "heading", h3: "heading", p: "paragraph", label: "label", div: "container" };
        return map[tag] || "custom";
    }

    createId() {
        return `el-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    }

    // =====================================================
    // UI (opsional)
    // =====================================================
    refresh() {
        this.currentHTML = this.getHTML();
        this.currentData = this.visualFrame?.getData();
        this.renderUI();
    }

    renderUI() {
        // ... (kalau kamu mau panel UI, tampilkan textarea data/html di sini)
    }
}

export default BuildController; 