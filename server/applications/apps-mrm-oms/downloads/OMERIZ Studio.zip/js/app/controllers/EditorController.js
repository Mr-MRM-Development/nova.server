import Library from "../../lib/Library.js";
import { Editor } from "../../vendor/editor/main.js";

class EditorController {

    static editor = null;

    static async init() {
        if (this.editor) {
            return this.editor;
        }

        const parent = await Library.waitForElement("#editor");

        this.editor = new Editor({
            parent: parent,
            doc: "",
            language: States.editor.language,
            theme: States.editor.theme,
            onCursor: ({ line, col }) => {
                States.editor.line = line;
                States.editor.col = col;
            }
        });

        States.editor.instance = this.editor;

        return this.editor;
    }

    static getEditor() {
        return this.editor;
    }

    static setValue(value) {
        if (!this.editor) {
            throw new Error("Editor belum diinisialisasi.");
        }

        this.editor.setValue(value);
    }

    static getValue() {
        if (!this.editor) {
            throw new Error("Editor belum diinisialisasi.");
        }

        return this.editor.getValue();
    }

    static setLanguage(language) {
        if (!this.editor) {
            throw new Error("Editor belum diinisialisasi.");
        }

        this.editor.setLanguage(language);
        States.editor.language = language;
    }

    static setTheme(theme) {
        if (!this.editor) {
            throw new Error("Editor belum diinisialisasi.");
        }

        this.editor.setTheme(theme);
        States.editor.theme = theme;
    }

    static focus() {
        this.editor?.focus();
    }
}

export default EditorController;