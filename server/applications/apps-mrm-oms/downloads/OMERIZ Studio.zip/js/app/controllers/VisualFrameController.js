import Elements from "../../global/element.js";
import Library from "../../lib/Library.js";
import States from "../../global/state.js";


class VisualFrameController {

    constructor(toolbox, options = {}) {
        this.toolbox = toolbox;

        this.frame = {};
        this.body = null;
        this.propertiesBody = null;

        this.selected = null;
        this.selectedSet = new Set();
        this.debug = options.debug ?? false;

        this.snap = {
            enabled: true,
            edgeRange: 6,
            releaseRange: 18,
            resist: 0.35,
            gap: 10,
            alignRange: 6
        };

        this.data = {
            version: 3,
            type: "visual-frame",
            frame: { width: 800, height: 600 },
            elements: []            // flat, tiap item punya parentId
        };

        this.clipboard = [];
        this.history = [];
        this.historyIndex = -1;

        this._dropTarget = null;
        this._compiling = false;

        this.init();
    }

    log(label, value) {
        const msg = value !== undefined
            ? `[VisualFrame] ${label}: ${value}`
            : `[VisualFrame] ${label}`;
        if (this.debug) alert(msg);
        console.log(msg);
    }

    // =====================================================
    // INIT
    // =====================================================
    async init() {
        this.body =
            Elements.frame?.body ||
            Elements.design?.body ||
            await Library.waitForElement("#frame-body, #design-body");

        this.propertiesBody =
            Elements.properties?.body ||
            await Library.waitForElement("#properties-body");

        if (!this.body) throw new Error("Frame body tidak ditemukan.");

        this.frame.body = this.body;
        this.frame.body.style.position = "relative";

        this.bindDragDrop();
        this.bindGlobalEvents();

        this.render();
        this.renderProperties();

        this.log("[init] selesai");
    }

    // =====================================================
    // DRAG-DROP DARI TOOLBOX
    // =====================================================
    bindDragDrop() {
        this.frame.body.addEventListener("dragover", event => {
            event.preventDefault();
            event.dataTransfer.dropEffect = "copy";
        });

        this.frame.body.addEventListener("drop", event => {
            event.preventDefault();

            const toolName = event.dataTransfer.getData("tool");
            if (!toolName) return;
            if (!this.toolbox?.getTool) return;

            const tool = this.toolbox.getTool(toolName);
            if (!tool) return;

            const rect = this.frame.body.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            const target = this.findDropTarget(event.clientX, event.clientY);

            this.create(tool, x, y, target);
        });
    }

    // =====================================================
    // CREATE
    // =====================================================
    create(tool, x, y, parent = null) {
        const data = this.createData(tool, x, y);

        const isParent = parent && parent !== this.frame.body;
        const parentId = isParent ? parent.dataset.id : null;

        data.parentId = parentId;

        // Kalau child, konversi koordinat ke relatif parent
        if (isParent) {
            const parentRect = parent.getBoundingClientRect();
            const frameRect = this.frame.body.getBoundingClientRect();
            const relX = x - (parentRect.left - frameRect.left);
            const relY = y - (parentRect.top - frameRect.top);
            data.visual.x = Math.max(0, Math.round(relX));
            data.visual.y = Math.max(0, Math.round(relY));
        }

        this.data.elements.push(data);

        const element = this.createVisual(data);
        const parentEl = parentId ? this.getEl(parentId) : this.frame.body;

        if (parentEl && parentEl !== this.frame.body) {
            parentEl.appendChild(element);
            parentEl.classList.add("has-children");
        } else {
            this.frame.body.appendChild(element);
        }

        this.select(element);
        this.pushHistory();
        return element;
    }

    createData(tool, x, y) {
        const clone = (obj) => {
            if (obj === undefined || obj === null) return {};
            if (typeof structuredClone === "function") {
                try { return structuredClone(obj); } catch (_) {}
            }
            return JSON.parse(JSON.stringify(obj));
        };

        const data = {
            id: this.createId(),
            parentId: null,
            tool: tool.name,
            visual: clone(tool.visual),
            element: clone(tool.element),
            compile: clone(tool.compile)
        };

        if (data.visual.width === undefined) data.visual.width = 100;
        if (data.visual.height === undefined) data.visual.height = 30;

        data.visual.x = Math.round(x);
        data.visual.y = Math.round(y);

        if (data.visual.element === undefined) {
            data.visual.element = data.element.tag || "div";
        }

        if (!data.element.attributes) data.element.attributes = {};

        return data;
    }

    createVisual(data) {
        const preview = document.createElement("div");

        preview.dataset.id = data.id;
        preview.dataset.tool = data.tool;
        preview.dataset.tag = data.element?.tag || "div";

        this.applyElement(preview, data.element);
        this.applyVisual(preview, data.visual);

        this.bindElement(preview);

        return preview;
    }

    // =====================================================
    // APPLY (data → DOM)
    // =====================================================
    applyElement(element, data = {}) {
        if (data.class !== undefined) element.className = data.class;

        if (data.style) {
            Object.entries(data.style).forEach(([name, value]) => {
                element.style[name] = this.toCSSValue(name, value);
            });
        }

        if (data.attributes) {
            Object.entries(data.attributes).forEach(([name, value]) => {
                if (value === null || value === undefined) return;
                if (this.isNativeBehaviorAttr(name)) return;
                element.setAttribute(name, value);
            });
        }

        if (data.textContent !== undefined && data.textContent !== null) {
            const handles = Array.from(element.querySelectorAll(":scope > .vf-handle"));
            const childEls = Array.from(element.children).filter(c => !c.classList.contains("vf-handle"));
            element.textContent = data.textContent;
            childEls.forEach(c => element.appendChild(c));
            handles.forEach(h => element.appendChild(h));
        }
    }

    isNativeBehaviorAttr(name) {
        return [
            "type", "value", "src", "href",
            "checked", "disabled", "readonly", "required"
        ].includes(name);
    }

    applyVisual(element, visual = {}) {
        element.style.position = "absolute";

        if (visual.dock) {
            this.applyDock(element, visual.dock);
            return;
        }

        this.clearDock(element);

        if (visual.x !== undefined) element.style.left = `${visual.x}px`;
        if (visual.y !== undefined) element.style.top = `${visual.y}px`;
        if (visual.width !== undefined) element.style.width = `${visual.width}px`;
        if (visual.height !== undefined) element.style.height = `${visual.height}px`;
    }

    applyDock(element, dock) {
        element.dataset.dock = dock;

        // Reset semua posisi
        element.style.left = "";
        element.style.right = "";
        element.style.top = "";
        element.style.bottom = "";
        element.style.width = "";
        element.style.height = "";

        if (dock === "top") {
            element.style.left = "0";
            element.style.right = "0";
            element.style.top = "0";
        } else if (dock === "bottom") {
            element.style.left = "0";
            element.style.right = "0";
            element.style.bottom = "0";
        } else if (dock === "left") {
            element.style.top = "0";
            element.style.bottom = "0";
            element.style.left = "0";
        } else if (dock === "right") {
            element.style.top = "0";
            element.style.bottom = "0";
            element.style.right = "0";
        } else if (dock === "fill") {
            element.style.top = "0";
            element.style.left = "0";
            element.style.right = "0";
            element.style.bottom = "0";
        }
    }

    clearDock(element) {
        delete element.dataset.dock;
        element.style.right = "";
        element.style.bottom = "";
    }

    // =====================================================
    // FIND DROP TARGET (untuk nesting)
    // =====================================================
    findDropTarget(clientX, clientY) {
        const el = document.elementFromPoint(clientX, clientY);
        if (!el) return null;

        let target = el.closest(".el");
        while (target) {
            if (!this.selectedSet.has(target)) {
                const toolName = target.dataset.tool || "";
                if (this.canBeParent(toolName)) return target;
            }
            target = target.parentElement?.closest(".el") || null;
        }

        return null;
    }

    canBeParent(toolName) {
        return [
            "container", "card", "panel", "section", "nav", "header", "footer"
        ].includes(toolName);
    }

    // =====================================================
    // EVENT PER ELEMEN
    // =====================================================
    bindElement(element) {
        element.addEventListener("mousedown", (event) => {
            if (event.target.classList.contains("vf-handle")) return;
            event.stopPropagation();

            const isMulti = event.ctrlKey || event.metaKey || event.shiftKey;

            if (isMulti) {
                if (this.selectedSet.has(element)) {
                    this.removeFromSelection(element);
                    return;
                }
                this.addToSelection(element);
                this.startDrag(element, event);
                return;
            }

            if (!this.selectedSet.has(element)) {
                this.clearSelection();
                this.addToSelection(element);
            }

            this.startDrag(element, event);
        });
    }

    // =====================================================
    // SELECT
    // =====================================================
    select(element) {
        this.clearSelection();
        this.addToSelection(element);
    }

    addToSelection(element) {
        this.selectedSet.add(element);
        element.classList.add("selected");
        this.selected = element;

        this.renderSelectionUI();
        this.renderProperties();
    }

    removeFromSelection(element) {
        this.selectedSet.delete(element);
        element.classList.remove("selected");

        if (this.selected === element) {
            this.selected = this.selectedSet.size > 0
                ? [...this.selectedSet][this.selectedSet.size - 1]
                : null;
        }

        this.renderSelectionUI();
        this.renderProperties();
    }

    clearSelection() {
        this.selectedSet.forEach(el => {
            el.classList.remove("selected");
            el.querySelectorAll(":scope > .vf-handle").forEach(h => h.remove());
        });
        this.selectedSet.clear();
        this.selected = null;

        this.renderSelectionUI();
    }

    deselect() {
        this.clearSelection();
        this.renderProperties();
    }

    renderSelectionUI() {
        this.frame.body.querySelectorAll(".vf-handle").forEach(h => h.remove());

        if (this.selectedSet.size > 1) return;
        if (!this.selected) return;

        const element = this.selected;
        const data = this.get(element.dataset.id);
        const dock = data?.visual?.dock;

        // Tentukan handle yang relevan berdasarkan dock
        let dirs = ["tl", "tr", "bl", "br", "top", "bottom", "left", "right"];

        if (dock === "top" || dock === "bottom") {
            dirs = ["top", "bottom"];
        } else if (dock === "left" || dock === "right") {
            dirs = ["left", "right"];
        } else if (dock === "fill") {
            dirs = [];
        }

        const map = {
            tl:     { top: "-5px", left: "-5px", cursor: "nwse-resize" },
            tr:     { top: "-5px", right: "-5px", cursor: "nesw-resize" },
            bl:     { bottom: "-5px", left: "-5px", cursor: "nesw-resize" },
            br:     { bottom: "-5px", right: "-5px", cursor: "nwse-resize" },
            top:    { top: "-5px", left: "50%", transform: "translateX(-50%)", cursor: "ns-resize" },
            bottom: { bottom: "-5px", left: "50%", transform: "translateX(-50%)", cursor: "ns-resize" },
            left:   { left: "-5px", top: "50%", transform: "translateY(-50%)", cursor: "ew-resize" },
            right:  { right: "-5px", top: "50%", transform: "translateY(-50%)", cursor: "ew-resize" }
        };

        dirs.forEach(dir => {
            const h = document.createElement("div");
            h.className = `vf-handle vf-handle-${dir}`;
            h.dataset.dir = dir;

            Object.assign(h.style, {
                position: "absolute",
                width: "8px",
                height: "8px",
                background: "#007acc",
                border: "1.5px solid #181818",
                borderRadius: "50%",
                zIndex: "9999",
                boxShadow: "0 0 0 1px #007acc"
            }, map[dir]);

            h.addEventListener("mousedown", (e) => {
                e.stopPropagation();
                e.preventDefault();
                this.startResize(element, dir, e);
            });

            element.appendChild(h);
        });
    }

    // =====================================================
    // SNAP
    // =====================================================
    computeSnapCandidates(element) {
        const parent = element.parentElement;
        const parentW = parent === this.frame.body ? this.frame.body.clientWidth : parent.clientWidth;
        const parentH = parent === this.frame.body ? this.frame.body.clientHeight : parent.clientHeight;

        const w = element.offsetWidth;
        const h = element.offsetHeight;

        const xCandidates = [0, parentW - w, (parentW - w) / 2];
        const yCandidates = [0, parentH - h, (parentH - h) / 2];

        // Snap ke elemen **sibling** (parent yang sama)
        const myParent = element.parentElement;
        this.data.elements.forEach(otherData => {
            if (otherData.id === element.dataset.id) return;

            const other = this.getEl(otherData.id);
            if (!other) return;
            if (other.parentElement !== myParent) return;
            if (this.selectedSet.has(other)) return;

            const oL = other.offsetLeft;
            const oT = other.offsetTop;
            const oW = other.offsetWidth;
            const oH = other.offsetHeight;

            xCandidates.push(oL, oL + oW, oL - w, oL + oW - w, oL + (oW - w) / 2);
            xCandidates.push(oL - w - this.snap.gap, oL + oW + this.snap.gap);

            yCandidates.push(oT, oT + oH, oT - h, oT + oH - h, oT + (oH - h) / 2);
            yCandidates.push(oT - h - this.snap.gap, oT + oH + this.snap.gap);
        });

        return { x: xCandidates, y: yCandidates };
    }

    computeResizeSnapCandidates(element) {
        const parent = element.parentElement;
        const parentW = parent === this.frame.body ? this.frame.body.clientWidth : parent.clientWidth;
        const parentH = parent === this.frame.body ? this.frame.body.clientHeight : parent.clientHeight;

        const xCandidates = [0, parentW, parentW / 2];
        const yCandidates = [0, parentH, parentH / 2];

        const myParent = element.parentElement;
        this.data.elements.forEach(otherData => {
            if (otherData.id === element.dataset.id) return;

            const other = this.getEl(otherData.id);
            if (!other) return;
            if (other.parentElement !== myParent) return;
            if (this.selectedSet.has(other)) return;

            const oL = other.offsetLeft;
            const oT = other.offsetTop;
            const oW = other.offsetWidth;
            const oH = other.offsetHeight;

            xCandidates.push(oL, oL + oW, oL + oW / 2);
            yCandidates.push(oT, oT + oH, oT + oH / 2);
        });

        return { x: xCandidates, y: yCandidates };
    }

    applySoftSnap(value, candidates) {
        let bestTarget = null;
        let bestDist = Infinity;

        for (const c of candidates) {
            const d = Math.abs(value - c);
            if (d < bestDist) {
                bestDist = d;
                bestTarget = c;
            }
        }

        if (bestTarget === null) return value;
        if (bestDist < this.snap.edgeRange) return bestTarget;

        if (bestDist < this.snap.edgeRange + this.snap.releaseRange) {
            const t = (bestDist - this.snap.edgeRange) / this.snap.releaseRange;
            const dir = value > bestTarget ? 1 : -1;
            const compressed = bestDist * (1 - this.snap.resist * (1 - t));
            return bestTarget + dir * compressed;
        }

        return value;
    }

    // =====================================================
    // DRAG MOVE
    // =====================================================
    startDrag(element, event) {
        const data = this.get(element.dataset.id);

        // Kalau di-dock → lepas dock saat drag
        if (data?.visual?.dock) {
            delete data.visual.dock;
            this.clearDock(element);
            data.visual.x = element.offsetLeft;
            data.visual.y = element.offsetTop;
            data.visual.width = element.offsetWidth;
            data.visual.height = element.offsetHeight;
            this.applyVisual(element, data.visual);
        }

        const startX = event.clientX;
        const startY = event.clientY;

        const snapshot = [...this.selectedSet].map(el => ({
            el,
            startL: el.offsetLeft,
            startT: el.offsetTop,
            w: el.offsetWidth,
            h: el.offsetHeight
        }));

        const primary = snapshot.find(s => s.el === element) || snapshot[0];

        const parent = element.parentElement;
        const parentW = parent === this.frame.body ? this.frame.body.clientWidth : parent.clientWidth;
        const parentH = parent === this.frame.body ? this.frame.body.clientHeight : parent.clientHeight;

        const candidates = this.computeSnapCandidates(element);

        this.selectedSet.forEach(el => el.classList.add("vf-dragging"));

        const onMove = (e) => {
            let dx = e.clientX - startX;
            let dy = e.clientY - startY;

            if (this.snap.enabled && this.selectedSet.size === 1) {
                const snappedL = this.applySoftSnap(primary.startL + dx, candidates.x);
                const snappedT = this.applySoftSnap(primary.startT + dy, candidates.y);
                dx = snappedL - primary.startL;
                dy = snappedT - primary.startT;
            }

            let minL = Infinity, minT = Infinity, maxR = -Infinity, maxB = -Infinity;
            snapshot.forEach(s => {
                minL = Math.min(minL, s.startL + dx);
                minT = Math.min(minT, s.startT + dy);
                maxR = Math.max(maxR, s.startL + dx + s.w);
                maxB = Math.max(maxB, s.startT + dy + s.h);
            });

            if (minL < 0) dx -= minL;
            if (minT < 0) dy -= minT;
            if (maxR > parentW) dx -= (maxR - parentW);
            if (maxB > parentH) dy -= (maxB - parentH);

            snapshot.forEach(s => {
                const newL = Math.round(s.startL + dx);
                const newT = Math.round(s.startT + dy);

                s.el.style.left = `${newL}px`;
                s.el.style.top  = `${newT}px`;

                const d = this.get(s.el.dataset.id);
                if (d) {
                    d.visual.x = newL;
                    d.visual.y = newT;
                }
            });

            this.highlightDropTarget(e.clientX, e.clientY);
            this.updatePropertiesPanelLive();
            if (this.selectedSet.size === 1) this.showGuides(element);
        };

        const onUp = () => {
            document.removeEventListener("mousemove", onMove);
            document.removeEventListener("mouseup", onUp);
            this.selectedSet.forEach(el => el.classList.remove("vf-dragging"));
            this.clearGuides();

            const target = this._dropTarget;
            this.clearDropTarget();

            if (target && this.selectedSet.size === 1) {
                this.attachToParent(element, target);
            }

            this.pushHistory();
        };

        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup", onUp);
    }

    highlightDropTarget(clientX, clientY) {
        this.clearDropTarget();
        if (this.selectedSet.size !== 1) return;

        const target = this.findDropTarget(clientX, clientY);
        const current = this.selected?.parentElement;

        if (target && target !== current && target !== this.selected) {
            target.classList.add("vf-drop-target");
            this._dropTarget = target;
        }
    }

    clearDropTarget() {
        this.frame.body.querySelectorAll(".vf-drop-target").forEach(el => {
            el.classList.remove("vf-drop-target");
        });
        this._dropTarget = null;
    }

    // =====================================================
    // ATTACH / DETACH (parent-child)
    // =====================================================
    attachToParent(child, parent) {
        if (!child || !parent) return;
        if (child === parent) return;
        if (parent.contains(child)) return;
        if (child.contains(parent)) return;

        const childId = child.dataset.id;
        const parentId = parent.dataset.id;

        const childData = this.get(childId);
        if (!childData) return;

        // Hitung posisi relatif terhadap parent baru
        const parentRect = parent.getBoundingClientRect();
        const childRect = child.getBoundingClientRect();
        const relX = childRect.left - parentRect.left;
        const relY = childRect.top - parentRect.top;

        // Update parentId
        childData.parentId = parentId;

        // Update posisi (kecuali dock)
        if (!childData.visual.dock) {
            childData.visual.x = Math.max(0, Math.round(relX));
            childData.visual.y = Math.max(0, Math.round(relY));
        }

        // Pindah DOM
        parent.appendChild(child);
        this.applyVisual(child, childData.visual);

        parent.classList.add("has-children");

        this.log(`[attach] ${childId} → ${parentId}`);
    }

    detachFromParent(child) {
        if (!child) return;
        if (child.parentElement === this.frame.body) return;

        const childData = this.get(child.dataset.id);
        if (!childData) return;

        const oldParent = child.parentElement;

        // Hitung posisi absolut relatif frame
        const frameRect = this.frame.body.getBoundingClientRect();
        const childRect = child.getBoundingClientRect();
        const absX = childRect.left - frameRect.left;
        const absY = childRect.top - frameRect.top;

        // Update data
        childData.parentId = null;
        if (!childData.visual.dock) {
            childData.visual.x = Math.max(0, Math.round(absX));
            childData.visual.y = Math.max(0, Math.round(absY));
        }

        // Pindah DOM
        this.frame.body.appendChild(child);
        this.applyVisual(child, childData.visual);

        // Update old parent class
        if (oldParent && oldParent.classList.contains("el")) {
            const stillHas = this.data.elements.some(d => d.parentId === oldParent.dataset.id);
            oldParent.classList.toggle("has-children", stillHas);
        }
    }

    // =====================================================
    // GUIDES
    // =====================================================
    showGuides(element) {
        this.clearGuides();

        const parent = element.parentElement;
        const parentW = parent === this.frame.body ? this.frame.body.clientWidth : parent.clientWidth;
        const parentH = parent === this.frame.body ? this.frame.body.clientHeight : parent.clientHeight;

        const elW = element.offsetWidth;
        const elH = element.offsetHeight;
        const elL = element.offsetLeft;
        const elT = element.offsetTop;

        const tol = 2;

        // Guides ke sibling
        const myParent = element.parentElement;
        this.data.elements.forEach(otherData => {
            if (otherData.id === element.dataset.id) return;

            const other = this.getEl(otherData.id);
            if (!other) return;
            if (other.parentElement !== myParent) return;
            if (this.selectedSet.has(other)) return;

            const oL = other.offsetLeft;
            const oT = other.offsetTop;
            const oW = other.offsetWidth;
            const oH = other.offsetHeight;

            if (Math.abs(elL - oL) < tol) this.drawGuideLine("v", oL);
            if (Math.abs(elL + elW - (oL + oW)) < tol) this.drawGuideLine("v", oL + oW);
            if (Math.abs(elL + elW / 2 - (oL + oW / 2)) < tol) this.drawGuideLine("v", oL + oW / 2);

            if (Math.abs(elT - oT) < tol) this.drawGuideLine("h", oT);
            if (Math.abs(elT + elH - (oT + oH)) < tol) this.drawGuideLine("h", oT + oH);
            if (Math.abs(elT + elH / 2 - (oT + oH / 2)) < tol) this.drawGuideLine("h", oT + oH / 2);
        });

        // Guides ke parent (center)
        if (Math.abs(elL + elW / 2 - parentW / 2) < tol) this.drawGuideLine("v", parentW / 2);
        if (Math.abs(elT + elH / 2 - parentH / 2) < tol) this.drawGuideLine("h", parentH / 2);
    }

    drawGuideLine(orientation, position) {
        const line = document.createElement("div");
        line.className = "vf-guide";

        Object.assign(line.style, {
            position: "absolute",
            background: "#4ec9b0",
            pointerEvents: "none",
            zIndex: "99998",
            opacity: "0.9"
        });

        if (orientation === "v") {
            line.style.left = `${position}px`;
            line.style.top = "0";
            line.style.width = "1px";
            line.style.height = "100%";
        } else {
            line.style.top = `${position}px`;
            line.style.left = "0";
            line.style.height = "1px";
            line.style.width = "100%";
        }

        this.frame.body.appendChild(line);
    }

    clearGuides() {
        this.frame.body.querySelectorAll(".vf-guide").forEach(g => g.remove());
    }

    // =====================================================
    // RESIZE
    // =====================================================
    startResize(element, dir, event) {
        const MIN_W = 20;
        const MIN_H = 16;

        const data = this.get(element.dataset.id);
        const dock = data?.visual?.dock;

        // Batasi handle saat di-dock
        if (dock === "top" || dock === "bottom") {
            if (!["top", "bottom"].includes(dir)) return;
        } else if (dock === "left" || dock === "right") {
            if (!["left", "right"].includes(dir)) return;
        } else if (dock === "fill") {
            return;
        }

        const startX = event.clientX;
        const startY = event.clientY;

        const startW = element.offsetWidth;
        const startH = element.offsetHeight;
        const startL = element.offsetLeft;
        const startT = element.offsetTop;

        const parent = element.parentElement;
        const parentW = parent === this.frame.body ? this.frame.body.clientWidth : parent.clientWidth;
        const parentH = parent === this.frame.body ? this.frame.body.clientHeight : parent.clientHeight;

        const candidates = this.computeResizeSnapCandidates(element);

        element.classList.add("vf-dragging");

        const onMove = (e) => {
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;

            let newW = startW;
            let newH = startH;
            let newL = startL;
            let newT = startT;

            if (dir.includes("r")) newW = startW + dx;
            else if (dir.includes("l")) { newW = startW - dx; newL = startL + dx; }

            if (dir.includes("b")) newH = startH + dy;
            else if (dir.includes("t")) { newH = startH - dy; newT = startT + dy; }

            // Snap
            if (this.snap.enabled && !dock) {
                if (dir.includes("r")) {
                    const snapped = this.applySoftSnap(newL + newW, candidates.x);
                    newW = snapped - newL;
                }
                if (dir.includes("l")) {
                    const snapped = this.applySoftSnap(newL, candidates.x);
                    newW = newL + newW - snapped;
                    newL = snapped;
                }
                if (dir.includes("b")) {
                    const snapped = this.applySoftSnap(newT + newH, candidates.y);
                    newH = snapped - newT;
                }
                if (dir.includes("t")) {
                    const snapped = this.applySoftSnap(newT, candidates.y);
                    newH = newT + newH - snapped;
                    newT = snapped;
                }
            }

            // Min size
            if (newW < MIN_W) {
                if (dir.includes("l")) newL = startL + (startW - MIN_W);
                newW = MIN_W;
            }
            if (newH < MIN_H) {
                if (dir.includes("t")) newT = startT + (startH - MIN_H);
                newH = MIN_H;
            }

            // Apply berdasarkan dock
            if (dock === "top" || dock === "bottom") {
                element.style.height = `${Math.round(newH)}px`;
                if (data) data.visual.height = Math.round(newH);
            } else if (dock === "left" || dock === "right") {
                element.style.width = `${Math.round(newW)}px`;
                if (data) data.visual.width = Math.round(newW);
            } else if (dock === "fill") {
                // skip
            } else {
                // Bebas — clamp ke parent
                if (newL < 0) { newW += newL; newL = 0; }
                if (newT < 0) { newH += newT; newT = 0; }
                if (newL + newW > parentW) newW = parentW - newL;
                if (newT + newH > parentH) newH = parentH - newT;

                element.style.width = `${Math.round(newW)}px`;
                element.style.height = `${Math.round(newH)}px`;
                element.style.left = `${Math.round(newL)}px`;
                element.style.top  = `${Math.round(newT)}px`;

                if (data) {
                    data.visual.x = Math.round(newL);
                    data.visual.y = Math.round(newT);
                    data.visual.width = Math.round(newW);
                    data.visual.height = Math.round(newH);
                }
            }

            this.updatePropertiesPanelLive();
        };

        const onUp = () => {
            document.removeEventListener("mousemove", onMove);
            document.removeEventListener("mouseup", onUp);
            element.classList.remove("vf-dragging");
            this.clearGuides();
            this.pushHistory();
        };

        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup", onUp);
    }

        // =====================================================
    // GLOBAL EVENTS
    // =====================================================
    bindGlobalEvents() {
        this.frame.body.addEventListener("mousedown", (event) => {
            if (event.target !== this.frame.body) return;
            this.deselect();
            this.startMarquee(event);
        });

        document.addEventListener("keydown", (event) => {
            if (States?.edit?.on !== "design") return;

            const tag = document.activeElement?.tagName;
            if (["INPUT", "TEXTAREA", "SELECT"].includes(tag)) return;

            if ((event.key === "Delete" || event.key === "Backspace") && this.selectedSet.size > 0) {
                event.preventDefault();
                this.deleteSelected();
            }

            if (event.key === "Escape") this.deselect();

            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "a") {
                event.preventDefault();
                this.clearSelection();
                this.data.elements.forEach(data => {
                    const el = this.getEl(data.id);
                    if (el) {
                        this.selectedSet.add(el);
                        el.classList.add("selected");
                    }
                });
                this.selected = [...this.selectedSet][this.selectedSet.size - 1] || null;
                this.renderSelectionUI();
                this.renderProperties();
            }

            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "c") {
                if (this.selectedSet.size > 0) {
                    event.preventDefault();
                    this.copySelected();
                }
            }

            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "v") {
                if (this.clipboard?.length > 0) {
                    event.preventDefault();
                    this.pasteClipboard();
                }
            }

            if ((event.ctrlKey || event.metaKey) && !event.shiftKey && event.key.toLowerCase() === "z") {
                event.preventDefault();
                this.undo();
            }

            if (
                ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key.toLowerCase() === "z") ||
                ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "y")
            ) {
                event.preventDefault();
                this.redo();
            }
        });
    }

    startMarquee(event) {
        const rect = this.frame.body.getBoundingClientRect();
        const startX = event.clientX - rect.left;
        const startY = event.clientY - rect.top;

        const box = document.createElement("div");
        Object.assign(box.style, {
            position: "absolute",
            border: "1px solid #007acc",
            background: "rgba(0,122,204,0.15)",
            pointerEvents: "none",
            zIndex: "99999",
            left: `${startX}px`,
            top: `${startY}px`,
            width: "0px",
            height: "0px"
        });

        this.frame.body.appendChild(box);

        const onMove = (e) => {
            const curX = e.clientX - rect.left;
            const curY = e.clientY - rect.top;

            const x = Math.min(startX, curX);
            const y = Math.min(startY, curY);
            const w = Math.abs(curX - startX);
            const h = Math.abs(curY - startY);

            box.style.left = `${x}px`;
            box.style.top = `${y}px`;
            box.style.width = `${w}px`;
            box.style.height = `${h}px`;

            const boxRect = { x, y, w, h };

            this.data.elements.forEach(data => {
                const el = this.getEl(data.id);
                if (!el) return;
                // Skip elemen yang punya parent (biar gak dobel)
                if (data.parentId) return;

                const elRect = {
                    x: el.offsetLeft,
                    y: el.offsetTop,
                    w: el.offsetWidth,
                    h: el.offsetHeight
                };

                const overlap = !(
                    elRect.x > boxRect.x + boxRect.w ||
                    elRect.x + elRect.w < boxRect.x ||
                    elRect.y > boxRect.y + boxRect.h ||
                    elRect.y + elRect.h < boxRect.y
                );

                if (overlap) el.classList.add("selected");
                else el.classList.remove("selected");
            });
        };

        const onUp = () => {
            document.removeEventListener("mousemove", onMove);
            document.removeEventListener("mouseup", onUp);
            box.remove();

            this.selectedSet.clear();
            this.frame.body.querySelectorAll("[data-id].selected").forEach(el => {
                this.selectedSet.add(el);
            });
            this.selected = [...this.selectedSet][this.selectedSet.size - 1] || null;

            this.renderSelectionUI();
            this.renderProperties();
        };

        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup", onUp);
    }

    // =====================================================
    // DELETE (recursive via parentId)
    // =====================================================
    deleteSelected() {
        const ids = [...this.selectedSet].map(el => el.dataset.id);
        this.clearSelection();

        // Kumpulkan semua descendant (child, grandchild, dst)
        const toDelete = new Set(ids);
        let changed = true;
        while (changed) {
            changed = false;
            this.data.elements.forEach(el => {
                if (el.parentId && toDelete.has(el.parentId) && !toDelete.has(el.id)) {
                    toDelete.add(el.id);
                    changed = true;
                }
            });
        }

        // Hapus dari DOM
        toDelete.forEach(id => {
            const el = this.getEl(id);
            if (!el) return;

            const parentEl = el.parentElement;
            el.remove();

            if (parentEl && parentEl.classList.contains("el")) {
                const parentId = parentEl.dataset.id;
                const stillHas = this.data.elements.some(
                    d => d.parentId === parentId && !toDelete.has(d.id)
                );
                parentEl.classList.toggle("has-children", stillHas);
            }
        });

        // Hapus dari data
        this.data.elements = this.data.elements.filter(el => !toDelete.has(el.id));

        this.renderProperties();
        this.pushHistory();
    }

    // =====================================================
    // RENDER FRAME (hierarchical dari flat list)
    // =====================================================
    render() {
        this.frame.body.innerHTML = "";
        this.applyFrame();

        const elMap = new Map();

        // 1. Bikin semua elemen (belum attach)
        this.data.elements.forEach(data => {
            const el = this.createVisual(data);
            elMap.set(data.id, el);
        });

        // 2. Attach ke parent masing-masing
        this.data.elements.forEach(data => {
            const el = elMap.get(data.id);
            if (!el) return;

            const parentEl = data.parentId ? elMap.get(data.parentId) : this.frame.body;

            if (parentEl) {
                parentEl.appendChild(el);
                if (parentEl !== this.frame.body) {
                    parentEl.classList.add("has-children");
                    parentEl.style.position = "relative";
                }
            } else {
                // Parent gak ketemu → jadi top-level
                this.frame.body.appendChild(el);
                data.parentId = null;
            }
        });
    }

    applyFrame() {
        const frame = this.data.frame || {};
        this.frame.body.style.position = "relative";
        if (frame.width !== undefined) this.frame.body.style.width = `${frame.width}px`;
        if (frame.height !== undefined) this.frame.body.style.height = `${frame.height}px`;
    }

    // =====================================================
    // GETTERS
    // =====================================================
    get(id) {
        return this.data.elements.find(el => el.id === id) || null;
    }

    getEl(id) {
        return this.frame.body.querySelector(`[data-id="${id}"]`);
    }

    getChildrenOf(id) {
        return this.data.elements.filter(el => el.parentId === id);
    }

    getParentOf(id) {
        const el = this.get(id);
        if (!el || !el.parentId) return null;
        return this.get(el.parentId);
    }

    getAll() { return this.data.elements; }
    getData() { return JSON.parse(JSON.stringify(this.data)); }

    // =====================================================
    // SET DATA (+ migrasi dari v1/v2)
    // =====================================================
    setData(data) {
        if (!data) return;
        const migrated = this._migrateData(JSON.parse(JSON.stringify(data)));
        this.data = migrated;
        this.deselect();
        this.render();
    }

    load(data) { this.setData(data); }

    _migrateData(data) {
        if (!data) return data;
        if (data.version === 3) return data;

        // Migrasi dari v1/v2 (nested children) → v3 (flat parentId)
        const flat = [];

        const walk = (list, parentId = null) => {
            (list || []).forEach(item => {
                const { children, ...rest } = item;
                rest.parentId = parentId;
                flat.push(rest);
                if (Array.isArray(children) && children.length) {
                    walk(children, item.id);
                }
            });
        };

        walk(data.elements || []);

        return {
            version: 3,
            type: data.type || "visual-frame",
            frame: data.frame || { width: 800, height: 600 },
            elements: flat
        };
    }

    // =====================================================
    // SYNC (DOM → data) — flat list, O(n)
    // =====================================================
    sync() {
        const domMap = new Map();
        this.frame.body.querySelectorAll("[data-id]").forEach(el => {
            domMap.set(el.dataset.id, el);
        });

        this.data.elements.forEach(data => {
            const element = domMap.get(data.id);
            if (!element) return;
            this.syncVisual(data, element);
            this.syncElement(data, element);
        });

        return this.getData();
    }

    syncVisual(data, element) {
        if (element.dataset.dock) {
            const dock = element.dataset.dock;
            data.visual.dock = dock;

            delete data.visual.x;
            delete data.visual.y;

            if (dock === "top" || dock === "bottom") {
                data.visual.height = element.offsetHeight;
                delete data.visual.width;
            } else if (dock === "left" || dock === "right") {
                data.visual.width = element.offsetWidth;
                delete data.visual.height;
            } else if (dock === "fill") {
                delete data.visual.width;
                delete data.visual.height;
            }
        } else {
            delete data.visual.dock;
            data.visual.x = element.offsetLeft;
            data.visual.y = element.offsetTop;
            data.visual.width = element.offsetWidth;
            data.visual.height = element.offsetHeight;
        }
    }

    syncElement(data, element) {
        const classList = Array.from(element.classList).filter(c =>
            c !== "selected" &&
            c !== "vf-dragging" &&
            c !== "vf-drop-target" &&
            c !== "has-children" &&
            !c.startsWith("vf-handle")
        );
        data.element.class = classList.join(" ");

        data.element.style = {};
        Array.from(element.style).forEach(prop => {
            if (["left", "top", "width", "height", "position", "right", "bottom"].includes(prop)) return;
            data.element.style[prop] = element.style[prop];
        });

        if (!data.element.attributes) data.element.attributes = {};

        Array.from(element.attributes).forEach(attr => {
            if (["class", "style", "data-id", "data-tool", "data-tag", "data-dock"].includes(attr.name)) return;
            data.element.attributes[attr.name] = attr.value;
        });

        if (!this.isVoidElement(data.element.tag)) {
            const clone = element.cloneNode(true);
            clone.querySelectorAll(".vf-handle").forEach(h => h.remove());
            clone.querySelectorAll("[data-id]").forEach(c => c.remove());
            data.element.textContent = clone.textContent;
        }
    }

    // =====================================================
    // SYNC COMPILE (data → compile tree)
    // =====================================================
    syncCompile() {
        const compileMap = new Map();
        const roots = [];

        // 1. Bikin compile node untuk tiap elemen
        this.data.elements.forEach(data => {
            compileMap.set(data.id, {
                tag: data.element.tag || "div",
                attributes: this._buildCompileAttributes(data),
                content: this.isVoidElement(data.element.tag) ? "" : (data.element.textContent ?? ""),
                children: []
            });
        });

        // 2. Susun tree via parentId
        this.data.elements.forEach(data => {
            const compile = compileMap.get(data.id);
            if (data.parentId && compileMap.has(data.parentId)) {
                compileMap.get(data.parentId).children.push(compile);
            } else {
                roots.push(compile);
            }
        });

        // 3. Simpan ke tiap data
        this.data.elements.forEach(data => {
            data.compile = compileMap.get(data.id);
        });

        return roots;
    }

    _buildCompileAttributes(data) {
        const element = data.element || {};
        const visual = data.visual || {};

        const attributes = { ...(element.attributes || {}) };

        if (element.class) {
            const cleanClass = element.class
                .split(/\s+/)
                .filter(c =>
                    c &&
                    c !== "selected" &&
                    c !== "vf-dragging" &&
                    c !== "vf-drop-target" &&
                    c !== "has-children" &&
                    !c.startsWith("vf-handle")
                )
                .join(" ");
            if (cleanClass) attributes.class = cleanClass;
        }

        if (element.value !== undefined) attributes.value = element.value;
        if (element.src !== undefined) attributes.src = element.src;
        if (element.href !== undefined) attributes.href = element.href;

        const style = { ...(element.style || {}) };

        if (visual.dock) {
            delete style.left; delete style.top;
            delete style.width; delete style.height;

            if (visual.dock === "top")    { style.left = "0"; style.right = "0"; style.top = "0"; }
            if (visual.dock === "bottom") { style.left = "0"; style.right = "0"; style.bottom = "0"; }
            if (visual.dock === "left")   { style.top = "0"; style.bottom = "0"; style.left = "0"; }
            if (visual.dock === "right")  { style.top = "0"; style.bottom = "0"; style.right = "0"; }
            if (visual.dock === "fill")   { style.top = "0"; style.left = "0"; style.right = "0"; style.bottom = "0"; }
        } else {
            if (visual.x !== undefined) style.left = `${visual.x}px`;
            if (visual.y !== undefined) style.top = `${visual.y}px`;
            if (visual.width !== undefined) style.width = `${visual.width}px`;
            if (visual.height !== undefined) style.height = `${visual.height}px`;
        }

        style.position = "absolute";
        attributes.style = this.stringifyStyle(style);

        return attributes;
    }

    stringifyStyle(style = {}) {
        return Object.entries(style)
            .filter(([_, v]) => v !== undefined && v !== null && v !== "")
            .map(([k, v]) => {
                const prop = k.replace(/[A-Z]/g, m => `-${m.toLowerCase()}`);
                return `${prop}:${v}`;
            })
            .join(";");
    }

    // =====================================================
    // COMPILE — SYNC
    // =====================================================
    compile() {
        return this.compileHTML();
    }

    compileHTML() {
        this.sync();
        const roots = this.syncCompile();
        return roots.map(root => this.compileElement(root)).join("");
    }

    // =====================================================
    // COMPILE — ASYNC (chunked)
    // =====================================================
    async compileHTMLAsync(options = {}) {
        if (this._compiling) {
            console.warn("[compile] masih berjalan, tunggu...");
            while (this._compiling) await this._yield();
        }

        this._compiling = true;

        try {
            const chunkSize = options.chunkSize || 50;
            const onProgress = options.onProgress || null;

            // 1. Sync DOM → data (chunked)
            const total = this.data.elements.length;
            const domMap = new Map();
            this.frame.body.querySelectorAll("[data-id]").forEach(el => {
                domMap.set(el.dataset.id, el);
            });

            let processed = 0;
            for (let i = 0; i < total; i += chunkSize) {
                const chunk = this.data.elements.slice(i, i + chunkSize);
                chunk.forEach(data => {
                    const el = domMap.get(data.id);
                    if (!el) return;
                    this.syncVisual(data, el);
                    this.syncElement(data, el);
                });
                processed += chunk.length;
                if (onProgress) onProgress(processed, total);
                await this._yield();
            }

            // 2. Build compile tree
            const roots = this.syncCompile();
            await this._yield();

            // 3. Render string (chunked)
            const parts = [];
            for (let i = 0; i < roots.length; i += chunkSize) {
                const chunk = roots.slice(i, i + chunkSize);
                chunk.forEach(root => parts.push(this.compileElement(root)));
                await this._yield();
            }

            return parts.join("");
        } finally {
            this._compiling = false;
        }
    }

    _yield() {
        return new Promise(resolve => setTimeout(resolve, 0));
    }

    compileElement(data) {
        if (!data) return "";
        const tag = data.tag || "div";
        const attributes = this.compileAttributes(data.attributes || {});
        const content = data.content || "";

        const children = Array.isArray(data.children)
            ? data.children.map(child => this.compileElement(child)).join("")
            : "";

        if (this.isVoidElement(tag)) return `<${tag}${attributes}>`;
        return `<${tag}${attributes}>${this.escapeHTML(content)}${children}</${tag}>`;
    }

    compileAttributes(attributes = {}) {
        return Object.entries(attributes)
            .map(([name, value]) => ` ${name}="${this.escapeAttribute(value)}"`)
            .join("");
    }

    // =====================================================
    // EXPORT / IMPORT JSON
    // =====================================================
    exportJSON(pretty = true) {
        this.sync();

        const payload = {
            version: 3,
            type: this.data.type || "visual-frame",
            frame: { ...this.data.frame },
            elements: JSON.parse(JSON.stringify(this.data.elements))
        };

        return pretty
            ? JSON.stringify(payload, null, 2)
            : JSON.stringify(payload);
    }

    importJSON(input) {
        if (!input) throw new Error("[importJSON] Input kosong.");

        let parsed;

        if (typeof input === "string") {
            try { parsed = JSON.parse(input); }
            catch (error) { throw new Error(`[importJSON] JSON tidak valid: ${error.message}`); }
        } else if (typeof input === "object") {
            parsed = JSON.parse(JSON.stringify(input));
        } else {
            throw new Error("[importJSON] Input harus string JSON atau object.");
        }

        if (!parsed.elements || !Array.isArray(parsed.elements)) {
            throw new Error("[importJSON] Field 'elements' tidak ada atau bukan array.");
        }

        parsed = this._migrateData(parsed);

        this.data = parsed;

        this.clearSelection();
        this.render();
        this.renderProperties();
        this.pushHistory();

        return this.getData();
    }

    // =====================================================
    // UTILS
    // =====================================================
    isVoidElement(tag) {
        return [
            "area", "base", "br", "col", "embed", "hr", "img",
            "input", "link", "meta", "param", "source", "track", "wbr"
        ].includes(String(tag).toLowerCase());
    }

    toCSSValue(name, value) {
        if (typeof value === "number") {
            if (["width", "height", "top", "left", "right", "bottom", "margin", "padding", "fontSize", "borderWidth", "borderRadius"].includes(name)) {
                return `${value}px`;
            }
        }
        return value;
    }

    escapeHTML(value) {
        return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    escapeAttribute(value) {
        return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    createId() {
        return `el-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    }

    // =====================================================
    // CLIPBOARD
    // =====================================================
    copySelected() {
        const ids = [...this.selectedSet].map(el => el.dataset.id);

        // Kumpulkan descendant juga
        const all = new Set(ids);
        let changed = true;
        while (changed) {
            changed = false;
            this.data.elements.forEach(el => {
                if (el.parentId && all.has(el.parentId) && !all.has(el.id)) {
                    all.add(el.id);
                    changed = true;
                }
            });
        }

        this.clipboard = [...all].map(id => {
            const data = this.get(id);
            return data ? JSON.parse(JSON.stringify(data)) : null;
        }).filter(Boolean);

        console.log(`[copy] ${this.clipboard.length} elemen`);
    }

    pasteClipboard() {
        if (!this.clipboard.length) return;

        // Map id lama → id baru
        const idMap = new Map();
        const newData = [];

        // Root id untuk di-paste (yang gak punya parent di clipboard)
        const clipboardIds = new Set(this.clipboard.map(d => d.id));
        const rootIds = this.clipboard
            .filter(d => !d.parentId || !clipboardIds.has(d.parentId))
            .map(d => d.id);

        this.clipboard.forEach(data => {
            const clone = JSON.parse(JSON.stringify(data));
            const oldId = clone.id;
            const newId = this.createId();
            idMap.set(oldId, newId);

            clone.id = newId;

            // Update parentId kalau parent ada di clipboard
            if (clone.parentId && clipboardIds.has(clone.parentId)) {
                clone.parentId = idMap.get(clone.parentId) || clone.parentId;
            } else {
                // Root yang di-paste → jadi top-level
                clone.parentId = null;
                if (!clone.visual.dock) {
                    clone.visual.x = (clone.visual.x || 0) + 20;
                    clone.visual.y = (clone.visual.y || 0) + 20;
                }
            }

            newData.push(clone);
        });

        // Push ke data
        newData.forEach(d => this.data.elements.push(d));

        // Render
        const elMap = new Map();
        newData.forEach(data => {
            const el = this.createVisual(data);
            elMap.set(data.id, el);
        });

        newData.forEach(data => {
            const el = elMap.get(data.id);
            const parentEl = data.parentId ? elMap.get(data.parentId) || this.getEl(data.parentId) : this.frame.body;

            if (parentEl) {
                parentEl.appendChild(el);
                if (parentEl !== this.frame.body) parentEl.classList.add("has-children");
            }
        });

        // Select hasil paste (root saja)
        this.clearSelection();
        const newRoots = newData.filter(d => rootIds.some(rid => idMap.get(rid) === d.id));
        newRoots.forEach(d => {
            const el = this.getEl(d.id);
            if (el) {
                this.selectedSet.add(el);
                el.classList.add("selected");
            }
        });
        this.selected = [...this.selectedSet][this.selectedSet.size - 1] || null;

        this.renderSelectionUI();
        this.renderProperties();
        this.pushHistory();

        console.log(`[paste] ${newData.length} elemen`);
    }

    // =====================================================
    // HISTORY
    // =====================================================
    pushHistory() {
        const snapshot = JSON.stringify(this.getData());

        if (this.historyIndex < this.history.length - 1) {
            this.history = this.history.slice(0, this.historyIndex + 1);
        }

        this.history.push(snapshot);

        if (this.history.length > 50) {
            this.history.shift();
        } else {
            this.historyIndex++;
        }
    }

    undo() {
        if (this.historyIndex <= 0) return;

        this.historyIndex--;
        const snapshot = this.history[this.historyIndex];

        this.data = JSON.parse(snapshot);
        this.clearSelection();
        this.render();
        this.renderProperties();
    }

    redo() {
        if (this.historyIndex >= this.history.length - 1) return;

        this.historyIndex++;
        const snapshot = this.history[this.historyIndex];

        this.data = JSON.parse(snapshot);
        this.clearSelection();
        this.render();
        this.renderProperties();
    }

    // =====================================================
    // PROPERTIES PANEL
    // =====================================================
    renderProperties() {
        if (!this.propertiesBody) return;
        this.propertiesBody.innerHTML = "";

        if (this.selectedSet.size === 0) {
            this.propertiesBody.innerHTML = `
                <div style="padding:40px 20px;text-align:center;color:#858585;font-size:11px;line-height:1.7;">
                    <i class="fa-solid fa-mouse-pointer" style="font-size:32px;color:#3e3e42;margin-bottom:12px;display:block;"></i>
                    Pilih komponen di canvas<br>untuk melihat propertinya
                </div>
            `;
            return;
        }

        if (this.selectedSet.size > 1) {
            this.renderMultiSelectProperties();
            return;
        }

        const id = this.selected.dataset.id;
        const data = this.get(id);
        if (!data) return;

        if (!data.element.attributes) data.element.attributes = {};

        const parent = data.parentId ? this.get(data.parentId) : null;

        const badge = document.createElement("div");
        badge.style.cssText = "padding:8px 10px;background:rgba(0,122,204,0.1);border:1px solid #007acc;border-radius:4px;margin-bottom:8px;color:#007acc;font-size:11px;font-weight:600;display:flex;gap:8px;align-items:center;";
        badge.innerHTML = `<i class="fa-solid fa-cube"></i><span>${data.id}</span><span style="margin-left:auto;color:#858585;font-weight:400;">${data.element.tag || "div"}</span>`;
        this.propertiesBody.appendChild(badge);

        if (parent) {
            const pBadge = document.createElement("div");
            pBadge.style.cssText = "padding:6px 10px;background:rgba(220,220,170,0.08);border:1px solid #dcdcaa;border-radius:4px;margin-bottom:8px;color:#dcdcaa;font-size:10px;";
            pBadge.innerHTML = `<i class="fa-solid fa-sitemap"></i> Child of <strong>${parent.id}</strong>`;
            this.propertiesBody.appendChild(pBadge);
        }

        this.renderIdentitySection(data);
        this.renderLayoutSection(data);
        this.renderDockSection(data);
        this.renderAttributesSection(data);
        this.renderTypographySection(data);
        this.renderBackgroundSection(data);
        this.renderSpacingSection(data);
        this.renderBorderSection(data);
        this.renderEffectsSection(data);
        this.renderActionsSection(data);
    }

    renderMultiSelectProperties() {
        const badge = document.createElement("div");
        badge.style.cssText = "padding:8px 10px;background:rgba(220,220,170,0.1);border:1px solid #dcdcaa;border-radius:4px;margin-bottom:8px;color:#dcdcaa;font-size:11px;font-weight:600;";
        badge.innerHTML = `<i class="fa-solid fa-object-group"></i> ${this.selectedSet.size} items selected`;
        this.propertiesBody.appendChild(badge);

        const actSec = this.makeSection("Actions", "fa-bolt");
        const actions = document.createElement("div");
        actions.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:4px;padding:4px;";

        actions.appendChild(this.makeButton("Align Left", "fa-align-left", () => this.alignSelected("left")));
        actions.appendChild(this.makeButton("Align Right", "fa-align-right", () => this.alignSelected("right")));
        actions.appendChild(this.makeButton("Align Top", "fa-arrow-up", () => this.alignSelected("top")));
        actions.appendChild(this.makeButton("Align Bottom", "fa-arrow-down", () => this.alignSelected("bottom")));
        actions.appendChild(this.makeButton("Center H", "fa-arrows-left-right", () => this.alignSelected("center-h")));
        actions.appendChild(this.makeButton("Center V", "fa-arrows-up-down", () => this.alignSelected("center-v")));

        const delBtn = this.makeButton("Delete All", "fa-trash", () => this.deleteSelected());
        delBtn.style.gridColumn = "1/-1";
        actions.appendChild(delBtn);

        actSec.body.appendChild(actions);
        this.propertiesBody.appendChild(actSec.el);
    }

    renderIdentitySection(data) {
        const sec = this.makeSection("Identity", "fa-fingerprint");

        sec.body.appendChild(this.makeRow("ID", this.makeInput("text", data.id, null, true)));
        sec.body.appendChild(this.makeRow("Tool", this.makeInput("text", data.tool, null, true)));
        sec.body.appendChild(this.makeRow("Parent", this.makeInput("text", data.parentId || "(none)", null, true)));

        sec.body.appendChild(this.makeRow("Tag", this.makeSelect(
            ["div", "button", "input", "textarea", "a", "img", "label", "h1", "h2", "h3", "h4", "h5", "h6", "p", "span", "ul", "ol", "li", "section", "header", "footer", "nav", "aside", "main", "article"],
            data.element.tag || "div",
            (v) => {
                data.element.tag = v;
                this.selected.dataset.tag = v;
            }
        )));

        this.propertiesBody.appendChild(sec.el);
    }

    renderLayoutSection(data) {
        const sec = this.makeSection("Layout", "fa-ruler-combined");
        const style = data.element.style = data.element.style || {};
        const dock = data.visual.dock;

        const grid = document.createElement("div");
        grid.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:6px;";

        const mkField = (label, prop, val) => {
            const wrap = document.createElement("div");
            wrap.style.cssText = "display:flex;flex-direction:column;gap:2px;";
            const l = document.createElement("label");
            l.textContent = label;
            l.style.cssText = "font-size:9px;color:#858585;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;";
            const input = document.createElement("input");
            input.type = "number";
            input.value = Math.round(val || 0);
            input.dataset.prop = prop;
            input.disabled = !!dock;
            input.style.cssText = `background:#3c3c3c;border:1px solid #3e3e42;border-radius:3px;padding:4px 6px;color:#cccccc;font-size:11px;outline:none;width:100%;box-sizing:border-box;${dock ? "opacity:0.4;" : ""}`;
            input.addEventListener("input", () => {
                const v = parseFloat(input.value);
                if (isNaN(v)) return;
                data.visual[prop] = v;
                const cssProp = prop === "x" ? "left" : prop === "y" ? "top" : prop;
                this.selected.style[cssProp] = v + "px";
            });
            wrap.appendChild(l);
            wrap.appendChild(input);
            return wrap;
        };

        grid.appendChild(mkField("X", "x", data.visual.x));
        grid.appendChild(mkField("Y", "y", data.visual.y));
        grid.appendChild(mkField("W", "width", data.visual.width));
        grid.appendChild(mkField("H", "height", data.visual.height));

        sec.body.appendChild(grid);

        if (dock) {
            const note = document.createElement("div");
            note.style.cssText = "font-size:10px;color:#dcdcaa;margin-bottom:6px;padding:4px 6px;background:rgba(220,220,170,0.08);border-radius:3px;";
            note.innerHTML = `<i class="fa-solid fa-lock"></i> Layout dikunci karena Dock aktif`;
            sec.body.appendChild(note);
        }

        sec.body.appendChild(this.makeRow("Z-Index", this.makeNumber(
            parseInt(style.zIndex) || 0,
            (v) => { style.zIndex = v; this.selected.style.zIndex = v; }
        )));

        sec.body.appendChild(this.makeRow("Display", this.makeSelect(
            ["block", "inline", "inline-block", "flex", "inline-flex", "grid", "inline-grid", "none"],
            style.display || "block",
            (v) => { style.display = v; this.selected.style.display = v; }
        )));

        sec.body.appendChild(this.makeRow("Overflow", this.makeSelect(
            ["visible", "hidden", "scroll", "auto"],
            style.overflow || "visible",
            (v) => { style.overflow = v; this.selected.style.overflow = v; }
        )));

        this.propertiesBody.appendChild(sec.el);
    }

    renderDockSection(data) {
        const sec = this.makeSection("Dock", "fa-anchor");
        const visual = data.visual;
        const currentDock = visual.dock || "";

        const info = document.createElement("div");
        info.style.cssText = "font-size:10px;color:#858585;margin-bottom:6px;line-height:1.4;";
        info.innerHTML = `Dock = nempel ke sisi <strong>parent</strong>. Kalau kosong → posisi bebas.`;
        sec.body.appendChild(info);

        sec.body.appendChild(this.makeRow("Position", this.makeSelect(
            ["", "top", "bottom", "left", "right", "fill"],
            currentDock,
            (v) => {
                if (v) {
                    visual.dock = v;

                    if (v === "top" || v === "bottom") {
                        visual.height = this.selected.offsetHeight;
                        delete visual.width;
                    } else if (v === "left" || v === "right") {
                        visual.width = this.selected.offsetWidth;
                        delete visual.height;
                    } else if (v === "fill") {
                        delete visual.width;
                        delete visual.height;
                    }

                    delete visual.x;
                    delete visual.y;
                } else {
                    delete visual.dock;
                    visual.x = this.selected.offsetLeft;
                    visual.y = this.selected.offsetTop;
                    visual.width = this.selected.offsetWidth;
                    visual.height = this.selected.offsetHeight;
                }

                this.applyVisual(this.selected, visual);
                this.renderProperties();
                this.pushHistory();
            }
        )));

        if (currentDock) {
            const isVertical = currentDock === "top" || currentDock === "bottom";
            const isHorizontal = currentDock === "left" || currentDock === "right";

            if (isVertical || isHorizontal) {
                const sizeRow = document.createElement("div");
                sizeRow.style.cssText = "display:grid;grid-template-columns:1fr;gap:6px;margin-top:6px;";

                if (isVertical) {
                    sizeRow.appendChild(this.makeCompactField("Height",
                        visual.height || this.selected.offsetHeight,
                        (v) => {
                            visual.height = v;
                            this.selected.style.height = v + "px";
                        }
                    ));
                } else {
                    sizeRow.appendChild(this.makeCompactField("Width",
                        visual.width || this.selected.offsetWidth,
                        (v) => {
                            visual.width = v;
                            this.selected.style.width = v + "px";
                        }
                    ));
                }

                sec.body.appendChild(sizeRow);
            }

            const note = document.createElement("div");
            note.style.cssText = "font-size:10px;color:#dcdcaa;margin-top:6px;padding:4px 6px;background:rgba(220,220,170,0.08);border-radius:3px;line-height:1.4;";
            note.innerHTML = isVertical
                ? `<i class="fa-solid fa-info-circle"></i> Lebar otomatis ikut parent. Atur Height saja.`
                : isHorizontal
                    ? `<i class="fa-solid fa-info-circle"></i> Tinggi otomatis ikut parent. Atur Width saja.`
                    : `<i class="fa-solid fa-info-circle"></i> Full mengisi parent. Size dikunci.`;
            sec.body.appendChild(note);
        }

        this.propertiesBody.appendChild(sec.el);
    }

    renderAttributesSection(data) {
        const sec = this.makeSection("Attributes", "fa-tag");
        const tag = (data.element.tag || "div").toLowerCase();
        const attrs = data.element.attributes = data.element.attributes || {};

        sec.body.appendChild(this.makeRow("html id", this.makeInput("text", attrs.id ?? "", (v) => {
            if (v) attrs.id = v; else delete attrs.id;
            if (v) this.selected.setAttribute("id", v); else this.selected.removeAttribute("id");
        })));

        sec.body.appendChild(this.makeRow("class", this.makeInput("text", data.element.class ?? "", (v) => {
            data.element.class = v;
            this.selected.className = v;
        })));

        sec.body.appendChild(this.makeRow("name", this.makeInput("text", attrs.name ?? "", (v) => {
            if (v) attrs.name = v; else delete attrs.name;
            if (v) this.selected.setAttribute("name", v); else this.selected.removeAttribute("name");
        })));

        sec.body.appendChild(this.makeRow("title", this.makeInput("text", attrs.title ?? "", (v) => {
            if (v) attrs.title = v; else delete attrs.title;
            if (v) this.selected.setAttribute("title", v); else this.selected.removeAttribute("title");
        })));

        if (tag === "a") {
            sec.body.appendChild(this.makeRow("href", this.makeInput("text", data.element.href ?? attrs.href ?? "", (v) => {
                data.element.href = v;
                if (v) attrs.href = v; else delete attrs.href;
            })));

            sec.body.appendChild(this.makeRow("target", this.makeSelect(
                ["_self", "_blank", "_parent", "_top"], attrs.target || "_self",
                (v) => { if (v) attrs.target = v; else delete attrs.target; }
            )));
        }

        if (tag === "img") {
            sec.body.appendChild(this.makeRow("src", this.makeInput("text", data.element.src ?? attrs.src ?? "", (v) => {
                data.element.src = v;
                if (v) attrs.src = v; else delete attrs.src;
            })));

            sec.body.appendChild(this.makeRow("alt", this.makeInput("text", attrs.alt ?? "", (v) => {
                if (v) attrs.alt = v; else delete attrs.alt;
            })));
        }

        if (tag === "input" || tag === "textarea") {
            sec.body.appendChild(this.makeRow("placeholder", this.makeInput("text", attrs.placeholder ?? "", (v) => {
                if (v) attrs.placeholder = v; else delete attrs.placeholder;
            })));

            sec.body.appendChild(this.makeRow("value", this.makeInput("text", data.element.value ?? attrs.value ?? "", (v) => {
                data.element.value = v;
                if (v) attrs.value = v; else delete attrs.value;
            })));

            if (tag === "input") {
                sec.body.appendChild(this.makeRow("type", this.makeSelect(
                    ["text", "password", "email", "number", "tel", "url", "search", "date", "time", "datetime-local", "color", "range", "file", "checkbox", "radio", "hidden"],
                    attrs.type || "text",
                    (v) => { if (v) attrs.type = v; else delete attrs.type; }
                )));
            }
        }

        sec.body.appendChild(this.makeRow("onclick", this.makeInput("text", attrs.onclick ?? "", (v) => {
            if (v) attrs.onclick = v; else delete attrs.onclick;
        })));

        this.propertiesBody.appendChild(sec.el);
    }

    renderTypographySection(data) {
        const sec = this.makeSection("Typography", "fa-font");
        const style = data.element.style = data.element.style || {};

        if (!this.isVoidElement(data.element.tag)) {
            sec.body.appendChild(this.makeRow("Content", this.makeTextarea(
                data.element.textContent ?? "",
                (v) => {
                    data.element.textContent = v;
                    this.applyElement(this.selected, data.element);
                }
            )));
        }

        sec.body.appendChild(this.makeRow("Font", this.makeSelect(
            ["Inter", "system-ui", "Arial", "Helvetica", "Georgia", "Times New Roman", "Courier New", "monospace", "serif", "sans-serif"],
            style.fontFamily || "Inter",
            (v) => { style.fontFamily = v; this.selected.style.fontFamily = v; }
        )));

        sec.body.appendChild(this.makeRow("Size", this.makeNumber(
            parseInt(style.fontSize) || 14,
            (v) => { style.fontSize = v + "px"; this.selected.style.fontSize = v + "px"; }
        )));

        sec.body.appendChild(this.makeRow("Weight", this.makeSelect(
            ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
            String(style.fontWeight || "400"),
            (v) => { style.fontWeight = v; this.selected.style.fontWeight = v; }
        )));

        sec.body.appendChild(this.makeRow("Align", this.makeSelect(
            ["left", "center", "right", "justify"],
            style.textAlign || "left",
            (v) => { style.textAlign = v; this.selected.style.textAlign = v; }
        )));

        sec.body.appendChild(this.makeRow("Color", this.makeColor(
            this.toHexColor(style.color),
            (v) => { style.color = v; this.selected.style.color = v; }
        )));

        this.propertiesBody.appendChild(sec.el);
    }

    renderBackgroundSection(data) {
        const sec = this.makeSection("Background", "fa-fill-drip");
        const style = data.element.style = data.element.style || {};

        sec.body.appendChild(this.makeRow("Color", this.makeColor(
            this.toHexColor(style.background || style.backgroundColor),
            (v) => { style.background = v; this.selected.style.background = v; }
        )));

        sec.body.appendChild(this.makeRow("Opacity", this.makeNumber(
            parseFloat(style.opacity ?? 1),
            (v) => {
                const c = Math.max(0, Math.min(1, v));
                style.opacity = c;
                this.selected.style.opacity = c;
            },
            0.05
        )));

        this.propertiesBody.appendChild(sec.el);
    }

    renderSpacingSection(data) {
        const sec = this.makeSection("Spacing", "fa-arrows-left-right-to-line");
        const style = data.element.style = data.element.style || {};

        const grid = document.createElement("div");
        grid.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:6px;";

        grid.appendChild(this.makeCompactField("Pad T", parseInt(style.paddingTop) || 0, (v) => {
            style.paddingTop = v + "px";
            this.selected.style.paddingTop = v + "px";
        }));
        grid.appendChild(this.makeCompactField("Pad R", parseInt(style.paddingRight) || 0, (v) => {
            style.paddingRight = v + "px";
            this.selected.style.paddingRight = v + "px";
        }));
        grid.appendChild(this.makeCompactField("Pad B", parseInt(style.paddingBottom) || 0, (v) => {
            style.paddingBottom = v + "px";
            this.selected.style.paddingBottom = v + "px";
        }));
        grid.appendChild(this.makeCompactField("Pad L", parseInt(style.paddingLeft) || 0, (v) => {
            style.paddingLeft = v + "px";
            this.selected.style.paddingLeft = v + "px";
        }));

        sec.body.appendChild(grid);
        this.propertiesBody.appendChild(sec.el);
    }

    renderBorderSection(data) {
        const sec = this.makeSection("Border", "fa-border-all");
        const style = data.element.style = data.element.style || {};

        sec.body.appendChild(this.makeRow("Style", this.makeSelect(
            ["none", "solid", "dashed", "dotted", "double", "groove", "ridge"],
            style.borderStyle || "none",
            (v) => { style.borderStyle = v; this.selected.style.borderStyle = v; }
        )));

        sec.body.appendChild(this.makeRow("Width", this.makeNumber(
            parseInt(style.borderWidth) || 0,
            (v) => { style.borderWidth = v + "px"; this.selected.style.borderWidth = v + "px"; }
        )));

        sec.body.appendChild(this.makeRow("Color", this.makeColor(
            this.toHexColor(style.borderColor),
            (v) => { style.borderColor = v; this.selected.style.borderColor = v; }
        )));

        sec.body.appendChild(this.makeRow("Radius", this.makeNumber(
            parseInt(style.borderRadius) || 0,
            (v) => { style.borderRadius = v + "px"; this.selected.style.borderRadius = v + "px"; }
        )));

        this.propertiesBody.appendChild(sec.el);
    }

    renderEffectsSection(data) {
        const sec = this.makeSection("Effects", "fa-wand-magic-sparkles");
        const style = data.element.style = data.element.style || {};

        sec.body.appendChild(this.makeRow("Box Shadow", this.makeInput("text", style.boxShadow || "", (v) => {
            if (v) style.boxShadow = v; else delete style.boxShadow;
            this.selected.style.boxShadow = v;
        })));

        sec.body.appendChild(this.makeRow("Cursor", this.makeSelect(
            ["default", "pointer", "move", "grab", "text", "not-allowed", "crosshair", "wait"],
            style.cursor || "default",
            (v) => { style.cursor = v; this.selected.style.cursor = v; }
        )));

        this.propertiesBody.appendChild(sec.el);
    }

    renderActionsSection(data) {
        const sec = this.makeSection("Actions", "fa-bolt");
        const actions = document.createElement("div");
        actions.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:4px;padding:4px;";

        actions.appendChild(this.makeButton("Front", "fa-arrow-up", () => {
            this.selected.parentElement.appendChild(this.selected);
        }));

        actions.appendChild(this.makeButton("Back", "fa-arrow-down", () => {
            const first = this.selected.parentElement.firstElementChild;
            if (first && first !== this.selected) {
                this.selected.parentElement.insertBefore(this.selected, first);
            }
        }));

        actions.appendChild(this.makeButton("Duplicate", "fa-copy", () => {
            const clone = JSON.parse(JSON.stringify(data));
            clone.id = this.createId();
            if (!clone.visual.dock) {
                clone.visual.x = (clone.visual.x || 0) + 20;
                clone.visual.y = (clone.visual.y || 0) + 20;
            }
            this.data.elements.push(clone);

            const el = this.createVisual(clone);
            const parentEl = clone.parentId ? this.getEl(clone.parentId) : this.frame.body;
            if (parentEl) parentEl.appendChild(el);

            this.select(el);
            this.pushHistory();
        }));

        actions.appendChild(this.makeButton("Detach", "fa-unlink", () => {
            this.detachFromParent(this.selected);
            this.pushHistory();
            this.renderProperties();
        }));

        const delBtn = this.makeButton("Delete", "fa-trash", () => this.deleteSelected());
        delBtn.style.gridColumn = "1/-1";
        actions.appendChild(delBtn);

        sec.body.appendChild(actions);
        this.propertiesBody.appendChild(sec.el);
    }

    alignSelected(mode) {
        const els = [...this.selectedSet].filter(el => !this.get(el.dataset.id)?.visual?.dock);
        if (els.length < 2) return;

        const boxes = els.map(el => ({
            el,
            l: el.offsetLeft,
            t: el.offsetTop,
            w: el.offsetWidth,
            h: el.offsetHeight
        }));

        const minL = Math.min(...boxes.map(b => b.l));
        const maxR = Math.max(...boxes.map(b => b.l + b.w));
        const minT = Math.min(...boxes.map(b => b.t));
        const maxB = Math.max(...boxes.map(b => b.t + b.h));
        const centerX = (minL + maxR) / 2;
        const centerY = (minT + maxB) / 2;

        boxes.forEach(b => {
            let newL = b.l;
            let newT = b.t;

            if (mode === "left") newL = minL;
            if (mode === "right") newL = maxR - b.w;
            if (mode === "top") newT = minT;
            if (mode === "bottom") newT = maxB - b.h;
            if (mode === "center-h") newL = centerX - b.w / 2;
            if (mode === "center-v") newT = centerY - b.h / 2;

            b.el.style.left = `${Math.round(newL)}px`;
            b.el.style.top  = `${Math.round(newT)}px`;

            const data = this.get(b.el.dataset.id);
            if (data) {
                data.visual.x = Math.round(newL);
                data.visual.y = Math.round(newT);
            }
        });

        this.pushHistory();
    }

    updatePropertiesPanelLive() {
        if (!this.propertiesBody || !this.selected) return;

        const data = this.get(this.selected.dataset.id);
        if (!data) return;

        const inputs = this.propertiesBody.querySelectorAll("input[data-prop]");
        inputs.forEach(input => {
            if (input === document.activeElement) return;
            if (input.disabled) return;
            const prop = input.dataset.prop;
            if (prop === "x") input.value = Math.round(data.visual.x || 0);
            if (prop === "y") input.value = Math.round(data.visual.y || 0);
            if (prop === "width") input.value = Math.round(data.visual.width || 0);
            if (prop === "height") input.value = Math.round(data.visual.height || 0);
        });
    }

    // =====================================================
    // PROPERTIES UI HELPERS
    // =====================================================
    makeSection(title, icon) {
        const el = document.createElement("div");
        el.style.cssText = "background:#2d2d30;border:1px solid #2d2d30;border-radius:4px;margin-bottom:6px;overflow:hidden;";
        const header = document.createElement("div");
        header.style.cssText = "display:flex;align-items:center;gap:6px;padding:6px 10px;background:#252526;font-size:10px;font-weight:600;color:#858585;text-transform:uppercase;letter-spacing:0.6px;cursor:pointer;border-bottom:1px solid #2d2d30;";
        header.innerHTML = `<i class="fa-solid ${icon}" style="color:#007acc;"></i><span>${title}</span>`;
        const body = document.createElement("div");
        body.style.cssText = "padding:6px;";
        header.addEventListener("click", () => {
            body.style.display = body.style.display === "none" ? "" : "none";
        });
        el.appendChild(header);
        el.appendChild(body);
        return { el, body };
    }

    makeRow(label, inputEl) {
        const row = document.createElement("div");
        row.style.cssText = "display:grid;grid-template-columns:90px 1fr;gap:6px;align-items:center;margin-bottom:4px;";
        const l = document.createElement("label");
        l.textContent = label;
        l.style.cssText = "font-size:11px;color:#858585;font-weight:500;";
        row.appendChild(l);
        row.appendChild(inputEl);
        return row;
    }

    makeInput(type, value, onChange, readonly = false) {
        const input = document.createElement("input");
        input.type = type;
        input.value = value ?? "";
        input.style.cssText = "background:#3c3c3c;border:1px solid #3e3e42;border-radius:3px;padding:4px 8px;color:#cccccc;font-family:inherit;font-size:11px;outline:none;width:100%;box-sizing:border-box;";
        if (readonly) { input.readOnly = true; input.style.background = "#252526"; }
        if (onChange) input.addEventListener("input", () => onChange(input.value));
        return input;
    }

    makeTextarea(value, onChange) {
        const ta = document.createElement("textarea");
        ta.value = value ?? "";
        ta.rows = 2;
        ta.style.cssText = "background:#3c3c3c;border:1px solid #3e3e42;border-radius:3px;padding:4px 8px;color:#cccccc;font-family:inherit;font-size:11px;outline:none;width:100%;box-sizing:border-box;resize:vertical;";
        ta.addEventListener("input", () => onChange(ta.value));
        return ta;
    }

    makeNumber(value, onChange, step = 1) {
        const input = document.createElement("input");
        input.type = "number";
        input.value = value;
        input.step = step;
        input.style.cssText = "background:#3c3c3c;border:1px solid #3e3e42;border-radius:3px;padding:4px 8px;color:#cccccc;font-size:11px;outline:none;width:100%;box-sizing:border-box;";
        input.addEventListener("input", () => {
            const v = parseFloat(input.value);
            if (!isNaN(v)) onChange(v);
        });
        return input;
    }

    makeSelect(options, value, onChange) {
        const select = document.createElement("select");
        select.style.cssText = "background:#3c3c3c;border:1px solid #3e3e42;border-radius:3px;padding:4px 8px;color:#cccccc;font-family:inherit;font-size:11px;outline:none;width:100%;box-sizing:border-box;cursor:pointer;";
        options.forEach(opt => {
            const o = document.createElement("option");
            o.value = opt;
            o.textContent = opt === "" ? "(none)" : opt;
            if (String(opt) === String(value)) o.selected = true;
            select.appendChild(o);
        });
        select.addEventListener("change", () => onChange(select.value));
        return select;
    }

    makeColor(value, onChange) {
        const input = document.createElement("input");
        input.type = "color";
        input.value = value || "#000000";
        input.style.cssText = "width:100%;height:22px;border:1px solid #3e3e42;border-radius:3px;background:#3c3c3c;cursor:pointer;padding:1px;box-sizing:border-box;";
        input.addEventListener("input", () => onChange(input.value));
        return input;
    }

    makeCompactField(label, value, onChange) {
        const wrap = document.createElement("div");
        wrap.style.cssText = "display:flex;flex-direction:column;gap:2px;";
        const l = document.createElement("label");
        l.textContent = label;
        l.style.cssText = "font-size:9px;color:#858585;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;";
        const input = document.createElement("input");
        input.type = "number";
        input.value = Math.round(value || 0);
        input.style.cssText = "background:#3c3c3c;border:1px solid #3e3e42;border-radius:3px;padding:4px 6px;color:#cccccc;font-size:11px;outline:none;width:100%;box-sizing:border-box;";
        input.addEventListener("input", () => {
            const v = parseFloat(input.value);
            if (!isNaN(v)) onChange(v);
        });
        wrap.appendChild(l);
        wrap.appendChild(input);
        return wrap;
    }

    makeButton(label, icon, onClick) {
        const btn = document.createElement("button");
        btn.style.cssText = "padding:6px 10px;background:#3c3c3c;border:1px solid #3e3e42;border-radius:3px;color:#cccccc;font-family:inherit;font-size:11px;font-weight:500;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:5px;";
        btn.innerHTML = `<i class="fa-solid ${icon}"></i> ${label}`;
        btn.addEventListener("click", onClick);
        return btn;
    }

    toHexColor(color) {
        if (!color) return "#000000";
        if (color.startsWith("#")) return color;
        const m = color.match(/\d+/g);
        if (!m) return "#000000";
        return "#" + m.slice(0, 3).map(n => parseInt(n).toString(16).padStart(2, "0")).join("");
    }
}

export default VisualFrameController;