import { App } from "./main.js";

function menuAction(name) {
    switch(name) {
        case "open":
            App.openProject();
        break;
    }
    closeAllMenus();
}

window.menuAction = menuAction;