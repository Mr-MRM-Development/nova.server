// ============================================================
// TREEVIEW
// ============================================================

window.toggleFolder = toggleFolder;
function toggleFolder(element) {

    const folder = element.parentElement.parentElement;

    const isOpen = folder.classList.toggle("open");

    element.setAttribute(
        "aria-expanded",
        isOpen
    );

}


// ============================================================
// FILE SELECTION
// ============================================================

window.selectFile = selectFile;
function selectFile(element) {

    document
        .querySelectorAll(
            ".tree-file.selected"
        )
        .forEach(
            (item) => {

                item.classList.remove(
                    "selected"
                );

            }
        );

    element.parentElement.classList.add(
        "selected"
    );

}